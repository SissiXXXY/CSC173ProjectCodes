//
// Created by sissi on 03/16/2021.
//

#ifndef CSC173_PROJECT2_EXPTREE_H
#define CSC173_PROJECT2_EXPTREE_H

#endif //CSC173_PROJECT2_EXPTREE_H
#include "parserTree.h"

extern tree expTree(tree parsechui);
extern void printExpression(tree input);
//extern void preorderTraverse(tree t);
//extern tree terminalNode(tree ter);
//extern int ifTerminal(tree test);

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//#include "parserTree.h"
#include "Problem2.h"
#include "testdriver.h"
#include "expTree.h"

void StartProblem2(char* input1) {
    printf("Part Two: This is the Tree that is printed using table driven parser\n");

    struct table* table1 = maketable();
    nodes* output = parsethrough(input1, table1);
    printTheTree(output);
    for (int i = 0; i < 8; i++) {
        free(table1->tableblocks[i]);
    }
    free(table1->tableblocks);
    free(table1);
}

int Part1(char* input){
    int Not = 0;
    printf("Part one: Use a recursive-descent parser to test whether the input is a regular expression\n");
    lookahead = input;
    tree parseTree = parse(input);
    if (parseTree == NULL) { //notice here
        printf("The input is not well-formed.\n");
        Not = 1;
    }
    else {
        //printf("printing tree");
        printTree(parseTree, 0);
    }
    return Not;
}

void Part3(char* input){
    printf("Part 3: Converting to expression tree...\n");
    lookahead = input;
    tree parseTree = parse(input);
    tree expchui = expTree(parseTree);
    printExpression(expchui);
    printf("\n");
}

int main(){
    printf("This is Project 2\n");
    printf("This project is done by Yao Xiao, Yuze Wang\n");
    printf("Please Enter an input, use QUIT to QUIT\n");
    char input[128];
    scanf("%s", input);
    while (strcmp(input, "QUIT\0")) {
        if (Part1(input) == 1) {
            printf("Input Rejected, Please Reenter\n");
            scanf("%s", input);
        }
        else {
            StartProblem2(input);
            Part3(input);
            printf("Input Accepted, Please Enter another input\n");
            scanf("%s", input);
        }
    }
}
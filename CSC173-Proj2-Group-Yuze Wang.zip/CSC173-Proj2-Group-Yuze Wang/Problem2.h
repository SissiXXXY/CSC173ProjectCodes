typedef struct table table;
typedef struct nodes nodes;
typedef struct stack stack;
typedef struct pointerstack pointerstack;

table* maketable();
nodes* parsethrough(char* parseinput, table* parsetable);
void printTheTree(nodes* root);
void printTheTree_RECURISION(nodes* root, int level);

int FindIndex(table* parsetable, char character, char currentParser);

void FUNCTION_E(stack* stack, nodes* nodesin, pointerstack* pointstack); //A
void FUNCTION_ET(stack* stack, char currentinput, nodes* nodesin, pointerstack* pointstack); //B
void FUNCTION_C(stack* stack, nodes* nodesin, pointerstack* pointstack); //C
void FUNCTION_CT(stack* stack, char currentinput,nodes* nodesin, pointerstack* pointstack); //D
void FUNCTION_S(stack* stack,nodes* nodesin, pointerstack* pointstack); //E
void FUNCTION_ST(stack* stack, char currentinput, nodes* nodesin, pointerstack* pointstack); //F
void FUNCTION_A(stack* stack, char currentinput, nodes* nodesin, pointerstack* pointstack); //G
void FUNCTION_X(stack* stack, char currentinput, nodes* nodesin, pointerstack* pointstack); //H

void addstack(stack* stack, char input);
char popStack(stack* stack);
void callFunc(int a, stack* stack, char currentinput, nodes* nodesin, pointerstack* pointstack);
int isEmpty(stack* stack);
void printstack(stack* stack);
nodes* createnode(char* input);
char* toProperstring(char in);
nodes* poppointerstack(pointerstack* points);
void addpointerstack(pointerstack* points, nodes* input);
void printPointerStack(pointerstack* stack);
int isEmptyPO(pointerstack* points);
struct table {
    char topcloumn[31];
    char *leftrow[8];
    int** tableblocks;
};

struct nodes {
    char* nodename;
    nodes* lefleaves;
    nodes* centralleaves;
    nodes* rightleaves;
};

struct stack {
    int Topindex;
    char* Stacks;
    int highestindex;
};
struct pointerstack {
    nodes** nodestacks;
    int Topindex;
};

//
// Created by sissi on 03/16/2021.
//
#include <stdio.h>
#include <stdlib.h>
#include "expTree.h"

tree expTree(tree parsechui){
    switch(*(parsechui->label)){
        case('E'):
            if(*(parsechui->first_lchild->next_sibling->first_lchild->label)=='|'){
                return makeNode2("|",expTree(parsechui->first_lchild),expTree(parsechui->first_lchild->next_sibling->first_lchild->next_sibling));
            }
            else{
                return expTree(parsechui->first_lchild);
            }
        case('C'):
            if(*(parsechui->first_lchild->next_sibling->first_lchild->label)=='.'){
                return makeNode2(".",expTree(parsechui->first_lchild),expTree(parsechui->first_lchild->next_sibling->first_lchild->next_sibling));
            }
            else{
                return expTree(parsechui->first_lchild);
            }
        case('S'):
            if(*(parsechui->first_lchild->next_sibling->first_lchild->label)=='*'){
                tree star=parsechui->first_lchild->next_sibling; //star=ST
                int starcount=0;
                while(star!=NULL&&(*(star->first_lchild->label)=='*')){
                    starcount=starcount+1;
                    star=star->first_lchild->next_sibling;
                }
                star = makeNode1("*", expTree(parsechui->first_lchild));
                for (int i = starcount-1; i > 0; i--) {
                    star = makeNode1("*", star);
                }
                return star;
            }
            else{
                return expTree((parsechui->first_lchild));
            }

        case('A'):
            if(*(parsechui->first_lchild->label)=='X'){
                return makeNode0(parsechui->first_lchild->first_lchild->label);
            }
            else{
                return makeNode3(" ",makeNode0("("),expTree(parsechui->first_lchild->next_sibling),makeNode0(")"));
            }
            /*if(*(parsechui->first_lchild->next_sibling->first_lchild->label)=='('){
                return makeNode3(" ",makeNode0("("),expTree(parsechui->first_lchild->next_sibling),makeNode0(")"));
            }
            else{
                return makeNode0(parsechui->first_lchild->first_lchild->label);
            }*/
        default:
            return NULL;
    }
}

void printExpression(tree input){
    if(input==NULL){
        return;
    }
    printf("(");
    if(*(input->label)=='|'){
        printf("UNION ");
        printExpression(input->first_lchild);
        printExpression(input->next_sibling);
        printf(")");
    }
    else if(*(input->label)=='.'){
        printf("CONCAT ");
        printExpression(input->first_lchild);
        printExpression(input->next_sibling);
        printf(")");
    }
    else if(*(input->label)=='*'){
        printf("CLOSURE ");
        printExpression(input->first_lchild);
        printExpression(input->next_sibling);
        printf(")");
    }
    else{
        printf("ATOMIC %s",input->label);
        printf(")");
        printExpression(input->first_lchild);
        printExpression(input->next_sibling);
    }

}

/*void preorderTraverse(tree t){
    if(t==NULL){
        return;
    }
    else{
        exptree=terminalNode(t);
        preorderTraverse(t->first_lchild);
        preorderTraverse(t->next_sibling);
    }
}



tree terminalNode(tree ter){
    switch (*(ter->label)) {
        case('a'):
            return(makeNode0("a"));
        case('b'):
            return(makeNode0("b"));
        case('c'):
            return(makeNode0("c"));
        case('d'):
            return(makeNode0("d"));
        case('e'):
            return(makeNode0("e"));
        case('f'):
            return(makeNode0("f"));
        case('g'):
            return(makeNode0("g"));
        case('h'):
            return(makeNode0("h"));
        case('i'):
            return(makeNode0("i"));
        case('j'):
            return(makeNode0("j"));
        case('k'):
            return(makeNode0("k"));
        case('l'):
            return(makeNode0("l"));
        case('m'):
            return(makeNode0("m"));
        case('n'):
            return(makeNode0("n"));
        case('o'):
            return(makeNode0("o"));
        case('p'):
            return(makeNode0("p"));
        case('q'):
            return(makeNode0("q"));
        case('r'):
            return(makeNode0("r"));
        case('s'):
            return(makeNode0("s"));
        case('t'):
            return(makeNode0("t"));
        case('u'):
            return(makeNode0("u"));
        case('v'):
            return(makeNode0("v"));
        case('w'):
            return(makeNode0("w"));
        case('x'):
            return(makeNode0("x"));
        case('y'):
            return(makeNode0("y"));
        case('z'):
            return(makeNode0("z"));
        case('|'):
            return(makeNode0("|"));
        case('.'):
            return(makeNode0("."));
        case('*'):
            return(makeNode0("*"));
        case('('):
            return(makeNode0("("));
        case(')'):
            return(makeNode0(")"));
        default:
            return NULL;
    }
    }
*/
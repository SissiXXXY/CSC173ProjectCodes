Collaborators: Yuze Wang (ywang349@u.rochester.edu)
     		   Yao Xiao (yxiao24@u.rochester.edu)

Procedure to build the project:
1.  Enter the exact directory of the files
2.  gcc -o rexp -std=c99 -Wall -Werror expTree.c expTree.h main.c parserTree.c parserTree.h Problem2.c Problem2.h testdriver.h
3. start rexp.exe

parserTree.c/.h are the files for problem 1, it is an implementation of recursive descent parser. It reads an input and tells if the input is a well-formed regualar expression. If it is, a parse tree will be printed.

Problem2.c/.h and testdriver.c are the files for problem 2, it implements the table driven parser and also gives feed back to the same imput and prints the parse tree.

expTree.c/.h are files for problem 3, it converts the parse tree created by previous two implementations into an expression tree. Then we have a method to print the prefix expression from the expression tree.
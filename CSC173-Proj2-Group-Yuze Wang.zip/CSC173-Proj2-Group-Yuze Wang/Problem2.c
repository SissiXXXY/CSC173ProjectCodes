#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Problem2.h"

void FUNCTION_E(stack* stack, nodes* nodesin, pointerstack* pointstack) {
    addstack(stack, 'B');
    addstack(stack, 'C');
    nodes* nodeleft = createnode("C");
    nodes* nodecenter = createnode("ET");
    nodesin->lefleaves = nodeleft;
    nodesin->centralleaves = nodecenter;
    addpointerstack(pointstack, nodecenter);
    addpointerstack(pointstack, nodeleft);
}
void FUNCTION_ET(stack* stack, char currentinput, nodes* nodesin, pointerstack* pointstack) {
    if (currentinput == '|') {
        addstack(stack, 'A');
        addstack(stack, '|');
        nodes* nodeleft = createnode("|");
        nodes* nodecenter = createnode("E");
        nodesin->lefleaves = nodeleft;
        nodesin->centralleaves = nodecenter;
        addpointerstack(pointstack, nodecenter);
        addpointerstack(pointstack, nodeleft);
    }
    else {
        addstack(stack, 'Z');
        nodes* nodeleft = createnode("esp");
        nodesin->lefleaves = nodeleft;
        addpointerstack(pointstack, nodeleft);
    }
}

void FUNCTION_C(stack* stack, nodes* nodesin, pointerstack* pointstack) {
    addstack(stack, 'D');
    addstack(stack, 'E');
    nodes* nodeleft = createnode("S");
    nodes* nodecenter = createnode("CT");
    nodesin->lefleaves = nodeleft;
    nodesin->centralleaves = nodecenter;
    addpointerstack(pointstack, nodecenter);
    addpointerstack(pointstack, nodeleft);
}

void FUNCTION_CT(stack* stack, char currentinput,nodes* nodesin, pointerstack* pointstack) {
    if (currentinput == '.') {
        addstack(stack, 'C');
        addstack(stack, '.');
        nodes* nodeleft = createnode(".");
        nodes* nodecenter = createnode("C");
        nodesin->lefleaves = nodeleft;
        nodesin->centralleaves = nodecenter;
        addpointerstack(pointstack, nodecenter);
        addpointerstack(pointstack, nodeleft);
    }
    else {
        addstack(stack, 'Z');
        nodes* nodeleft = createnode("esp");
        nodesin->lefleaves = nodeleft;
        addpointerstack(pointstack, nodeleft);
    }
}

void FUNCTION_S(stack* stack,nodes* nodesin, pointerstack* pointstack) {
    addstack(stack, 'F');
    addstack(stack, 'G');
    nodes* nodeleft = createnode("A");
    nodes* nodecenter = createnode("ST");
    nodesin->lefleaves = nodeleft;
    nodesin->centralleaves = nodecenter;
    addpointerstack(pointstack, nodecenter);
    addpointerstack(pointstack, nodeleft);
}

void FUNCTION_ST(stack* stack, char currentinput,nodes* nodesin, pointerstack* pointstack) {
    if (currentinput == '*') {
        addstack(stack, 'F');
        addstack(stack, '*');
        nodes* nodeleft = createnode("*");
        nodes* nodecenter = createnode("ST");
        nodesin->lefleaves = nodeleft;
        nodesin->centralleaves = nodecenter;
        addpointerstack(pointstack, nodecenter);
        addpointerstack(pointstack, nodeleft);
    }
    else {
        addstack(stack, 'Z');
        nodes* nodeleft = createnode("esp");
        nodesin->lefleaves = nodeleft;
        addpointerstack(pointstack, nodeleft);
    }
}

void FUNCTION_A(stack* stack, char currentinput,nodes* nodesin, pointerstack* pointstack) {
    if (currentinput == '(') {
        addstack(stack, ')');
        addstack(stack, 'A');
        addstack(stack, '(');
        nodes* nodeleft = createnode("(");
        nodes* nodecenter = createnode("E");
        nodes* noderight = createnode(")");
        nodesin->lefleaves = nodeleft;
        nodesin->centralleaves = nodecenter;
        nodesin->rightleaves = noderight;
        addpointerstack(pointstack, noderight);
        addpointerstack(pointstack, nodecenter);
        addpointerstack(pointstack, nodeleft);

    }
    else {
        addstack(stack, 'H');
        nodes* nodeleft = createnode("X");
        nodesin->lefleaves = nodeleft;
        addpointerstack(pointstack, nodeleft);
    }
}

void FUNCTION_X(stack* stack, char currentinput, nodes* nodesin, pointerstack* pointstack) {
    char a[] = "abcdefghijklmnopqrstuvwxyz";
    for (int i = 0; i < strlen(a); i++) {
        if (currentinput == a[i]) {
            addstack(stack, a[i]);
            char str[2] = "\0";
            str[0] = a[i];
            nodes* nodeleft = createnode(str);
            nodesin->lefleaves = nodeleft;
            addpointerstack(pointstack, nodeleft);
            break;
        }
    }
}

nodes* createnode(char* input) {
    nodes* output = (nodes*)malloc(sizeof(nodes));
    if (output != NULL) {
        output->nodename = malloc(strlen(input) + 1);
        strcpy(output->nodename, input);
        output->lefleaves = NULL;
        output->centralleaves = NULL;
        output->rightleaves = NULL;
    }
    return output;
}
int FindIndex(table* parsetable, char character, char currentParser) {
    int column = 0;
    int row = 0;
    for (int i = 0; i < strlen(parsetable->topcloumn); i++) {
        char a = parsetable->topcloumn[i];
        if (character == a) {
            column = i;
            break;
        }
    }
    if (currentParser == 'A') {
        row = 0;
    }
    if (currentParser == 'B') {
        row = 1;
    }
    if (currentParser == 'C') {
        row = 2;
    }
    if (currentParser == 'D') {
        row = 3;
    }
    if (currentParser == 'E') {
        row = 4;
    }
    if (currentParser == 'F') {
        row = 5;
    }
    if (currentParser == 'G') {
        row = 6;
    }
    if (currentParser == 'H') {
        row = 7;
    }
    //printf("Using Row: %d", parsetable->tableblocks[row][column]);
    return parsetable->tableblocks[row][column];
}
void addstack(stack* stack, char input) {
    if (stack->Topindex < 0) {
        stack->Stacks[0] = input;
        stack->Topindex = 0;
    }
    else if(stack->Topindex > 9){
        return;
    }
    else {
        stack->Topindex = stack->Topindex + 1;
        stack->Stacks[stack->Topindex] = input;
    }

}
char popStack(stack* stacks) {
    if(stacks->Topindex == 0){
        return -1;
    }else {
        char output = stacks->Stacks[stacks->Topindex];
        stacks->Stacks[stacks->Topindex] = '0';
        stacks->Topindex = stacks->Topindex - 1;
        return output;
    }
}
void callFunc(int a, stack *stack, char currentinput,nodes* nodesin, pointerstack* pointstack) {
    if (a == 0) {
        FUNCTION_E(stack, nodesin, pointstack);
    }
    if (a == 1) {
        FUNCTION_ET(stack, currentinput,nodesin, pointstack);
    }
    if (a == 2) {
        FUNCTION_C(stack,nodesin, pointstack);
    }
    if (a == 3) {
        FUNCTION_CT(stack, currentinput, nodesin, pointstack);
    }
    if (a == 4) {
        FUNCTION_S(stack, nodesin, pointstack);
    }
    if (a == 5) {
        FUNCTION_ST(stack, currentinput, nodesin, pointstack);
    }
    if (a == 6) {
        FUNCTION_A(stack, currentinput,nodesin, pointstack);
    }
    if (a == 7) {
        FUNCTION_X(stack, currentinput,nodesin, pointstack);
    }
}
void printstack(stack* stack) {
    printf("stack is:	");
    for (int i = 0; i < stack->Topindex; i++) {
        printf("%c ", stack->Stacks[i]);
    }
    printf("\n");
}
void printPointerStack(pointerstack* stack) {
    printf("The Pointer Stack is:	");
    for (int i = 0; i < stack->Topindex; i++) {
        printf("%s	", stack->nodestacks[i]->nodename);
    }
    printf("\n");
}
int isEmpty(stack* stack) {
    if (stack->Topindex < 0) {
        return 1;
    }
    else {
        return 0;
    }
}

int isEmptyPO(pointerstack* points) {
    if (points->Topindex < 0) {
        return 1;
    }
    else {
        return 0;
    }
}
nodes* poppointerstack(pointerstack* points) {
    if(points->Topindex == 0){
        nodes* outputNode = createnode("EMPTY");
        return outputNode;
    }else{
        nodes* outputNode = points->nodestacks[points->Topindex];
        points->nodestacks[points->Topindex] = NULL;
        points->Topindex = points->Topindex - 1;
        return outputNode;
    }
}
void addpointerstack(pointerstack* points, nodes* input) {
    if (points->Topindex < 0) {
        points->nodestacks[0] = input;
        points->Topindex = 0;
    }
    else if(points->Topindex > 9){
        return;
    }
    else {
        points->Topindex = points->Topindex + 1;
        points->nodestacks[points->Topindex] = input;
    }
}

//translate to proper Synatix Catagory
char* toProperstring(char in) {
    if (in == 'A') {
        return "E";
    }if (in == 'B') {
        return "ET";
    }if (in == 'C') {
        return "C";
    }if (in == 'D') {
        return "CT";
    }if (in == 'E') {
        return "S";
    }if (in == 'F') {
        return "ST";
    }if (in == 'G') {
        return "A";
    }if (in == 'H') {
        return "X";
    }
    return "\0";
}

nodes* parsethrough(char* parseinput, table* parsetable) {
    int currentIndex = 0;
    int ErrorRecord = 0;

    struct pointerstack* pointstack = (pointerstack*)malloc(sizeof(stack));
    pointstack->Topindex = 0;
    pointstack->nodestacks = (nodes**)malloc(sizeof(nodes*) * 10);

    struct stack* parsestack = (stack*)malloc(sizeof(stack));

    parsestack->Stacks = (char*)malloc(sizeof(char) * 10);
    parsestack->Topindex = 0;

    nodes* topnode = createnode("E");
    addstack(parsestack, 'A');
    addpointerstack(pointstack, topnode);

    //printf("String Length is: %d", strlen(parseinput));
    while (currentIndex < strlen(parseinput)+1 && ErrorRecord == 0) {
        //printf("Current Index is: %d\n", currentIndex);
        //printstack(parsestack);
        //printPointerStack(pointstack);
        if (isEmpty(parsestack)) {
            printf("Error Record is Call, Error Recorded\n");
            ErrorRecord = 1;
            break;
        }
        char currentParse = popStack(parsestack);
        nodes* currentNode = poppointerstack(pointstack);
        //printf("Current Char is: %c	\n", currentParse);
        //printf("Current Indent is: %d \n", currentIndent);
        if (currentParse == 'A' || currentParse == 'B' || currentParse == 'C' ||
            currentParse == 'D' || currentParse == 'E' || currentParse == 'F' || currentParse == 'G' || currentParse == 'H') {
            //printf("CURRENT NODE IS: %s\n", currentNode->nodename);
            int nexFunction = FindIndex(parsetable, parseinput[currentIndex], currentParse);
            //printf("IT IS A SyntaticCatagory, and the NextFunction is: %d\n", nexFunction);
            if (nexFunction != -1) {
                callFunc(nexFunction, parsestack, parseinput[currentIndex], currentNode, pointstack);
                if (currentNode->lefleaves != NULL) {
                    //printf("The Left Leaf is: %s\n", currentNode->lefleaves->nodename);
                }if (currentNode->centralleaves != NULL) {
                    //printf("The Central Leaf is: %s\n", currentNode->centralleaves->nodename);
                }if (currentNode->rightleaves != NULL) {
                    //printf("The Right Leaf is: %s\n", currentNode->rightleaves->nodename);
                }
            }
            else {
                ErrorRecord = 1;
                //printf("False Triggered, Terminating the Function");
                break;
            }
        }
        else if(currentParse == 'Z') {
            //printf("It is Epslion\n");
        }
        else {
            //printf("It is a Terminal Symbol\n");
            if (isEmptyPO(pointstack)) {
                break;
            }
            else {
                currentIndex++;
            }
        }
        //printf("\n\n");
    }

    if (ErrorRecord == 1 || currentIndex < strlen(parseinput)) {
        //printf("There is Error\n");
        topnode->lefleaves = NULL;
        topnode->centralleaves = NULL;
        topnode->lefleaves = NULL;
    }
    free(parsestack->Stacks);
    /*
    for (int i = 0; i < 10; i++) {
        printf("Freeing");
        free(parsestack->Stacks[i]);
        free(pointstack->nodestacks[i]);
    }
    */
    free(pointstack->nodestacks);
    free(pointstack);
    free(parsestack);
    return topnode;
}

void printtab(int numtabs) {
    for (int i = 0; i < numtabs; i++) {
        printf("  ");
    }
}

void printTheTree_RECURISION(nodes* root, int level) {
    if (root == NULL) {
        //printtab(level);
        //printf("EMPTY\n");
        return;
    }else{
        printtab(level);
        printf("%s\n", root->nodename);

        if(root->lefleaves != NULL){
            printtab(level);
            printTheTree_RECURISION(root->lefleaves, level+1);
        }
        if(root->centralleaves != NULL){
            printtab(level);
            printTheTree_RECURISION(root->centralleaves, level+1);
        }

        if(root->rightleaves != NULL){
            printtab(level);
            printTheTree_RECURISION(root->rightleaves, level+1);
        }
        free(root->nodename);
        free(root);
    }
    //printf("\n");
}

void printTheTree(nodes* root) {
    printTheTree_RECURISION(root, 0);
}

table* maketable() {
    //value of each table block represent the index number;
    struct table* parsetable = (table*)malloc(sizeof(table));
    parsetable->tableblocks = (int**)malloc(8 * sizeof(int*));
    strcpy(parsetable->topcloumn, "|*.(abcdefghijklmnopqrstuvwxyz\0");
    parsetable->leftrow[0] = "E";
    parsetable->leftrow[1] = "ET";
    parsetable->leftrow[2] = "C";
    parsetable->leftrow[3] = "CT";
    parsetable->leftrow[4] = "S";
    parsetable->leftrow[5] = "ST";
    parsetable->leftrow[6] = "A";
    parsetable->leftrow[7] = "X";

    for (int i = 0; i < 8; i++) {
        parsetable->tableblocks[i] = (int*)malloc(30 * sizeof(int));
    }


    //fill the table with -1 as false value
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 30; j++) {
            parsetable->tableblocks[i][j] = -1;
        }
    }
    for (int i = 3; i < 30; i++) {
        parsetable->tableblocks[0][i] = 0;
        parsetable->tableblocks[2][i] = 2;
        parsetable->tableblocks[4][i] = 4;
        parsetable->tableblocks[6][i] = 6;
    }
    for (int i = 4; i < 30; i++) {
        parsetable->tableblocks[7][i] = 7;
    }
    for (int i = 0; i < 30; i++) {
        parsetable->tableblocks[1][i] = 1;
        parsetable->tableblocks[3][i] = 3;
        parsetable->tableblocks[5][i] = 5;
    }
    return parsetable;
}

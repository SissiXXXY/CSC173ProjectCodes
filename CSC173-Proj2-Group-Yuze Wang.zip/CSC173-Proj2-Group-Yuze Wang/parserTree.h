//
// Created by sissi on 03/11/2021.
//

#ifndef CSC173_PROJ2_PARSERTREE_H
#define CSC173_PROJ2_PARSERTREE_H

#endif //CSC173_PROJ2_PARSERTREE_H

typedef struct node{
    struct node *first_lchild;
    struct node *next_sibling;
    char* label;
}node;
typedef struct node* tree;
extern void assign_lookahead(char* input);
extern tree makeNode0(char* x);
extern tree makeNode1(char* x, tree t);
extern tree makeNode2(char* x, tree t1, tree t2);
extern tree makeNode3(char* x, tree t1, tree t2, tree t3);
extern tree parse(char* inp);
extern void printTree(tree tree1,int depth1);
char* lookahead;
int depth;

extern tree E();
extern tree ET();
extern tree C();
extern tree CT();
extern tree S();
extern tree ST();
extern tree A();
extern tree X();


void StartProblem2();

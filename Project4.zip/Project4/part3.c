#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "part1.h"
#include "part3.h"


CSGList* selection_CSG(CSGList* CSGHash, char* course) {
    CSGList* newList = CSG_Create();
    for (int i = 0; i < 50; i++) {
        CSG* current = CSGHash->lists[i];
        while (current != NULL) {
            if (strcmp(current->Course, course) == 0) {
                Insert_CSG(newList, current->studentID, current->Course, current->grade);
            }
            current = current->nextCSG;
        }
    }
    return newList;
}

void Projection_CSG(CSGList* CSGHash, char* type) {
    int size1 = 0;
    for (int i = 0; i < 50; i++) {
        CSG* current = CSGHash->lists[i];
        while (current != NULL) {
            size1+=1;
            current = current->nextCSG;
        }
    }
    char** charList = (char**)malloc(sizeof(char*) * size1);
    int* intList = (int*)malloc(sizeof(int) * size1);
    int index = 0;
    for (int k = 0; k < 50; k++) {
        CSG* current1 = CSGHash->lists[k];
        while (current1 != NULL) {
            if (strcmp(type, "course") == 0) {
                charList[index] = (char*)malloc(strlen(current1->Course) + 1);
                strcpy(charList[index], current1->Course);
                index++;
            }
            else if (strcmp(type, "studentid") == 0) {
                intList[index] = current1->studentID;
                index++;
            }
            else if (strcmp(type, "grade") == 0) {
                charList[index] = (char*)malloc(strlen(current1->Course) + 1);
                strcpy(charList[index], current1->grade);
                index++;
            }
            current1 = current1->nextCSG;
        }
    }

    if (strcmp(type, "grade") == 0 || strcmp(type, "course") == 0) {
        for (int j = 0; j < size1; j++) {
            printf("%s\n", charList[j]);
        }
        for (int z = 0; z < size1; z++) {
            free(charList[z]);
        }
        free(charList);
        free(intList);
    }
    else {
        printf("student ID\n");
        for (int f = 0; f < size1; f++) {
            printf("%d\n", intList[f]);
        }
        free(intList);
        free(charList);
    }


}

CRDHList* CRDH_Create() {
    struct CRDHList* Hashtable = (CRDHList*)malloc(sizeof(CRDHList));
    Hashtable->lists = (CRDH**)malloc(sizeof(CRDH) * 50);
    for (int i = 0; i < 50; i++) {
        Hashtable->lists[i] = NULL;
    }
    return Hashtable;
}

CRDH* makeCRDH(char* course, char* room, char* Day, char* Hour) {
    struct CRDH* output = (CRDH*)malloc(sizeof(CRDH));
    output->course = (char*)malloc(strlen(course) + 1);
    output->room = (char*)malloc(strlen(room) + 1);
    output->Day = (char*)malloc(strlen(Day) + 1);
    output->Hour = (char*)malloc(strlen(Hour) + 1);
    strcpy(output->course, course);
    strcpy(output->room, room);
    strcpy(output->Day, Day);
    strcpy(output->Hour, Hour);
    output->nextCRDH = NULL;
    return output;
}

void insert_CRDH(CRDHList* CRDHHash, char* course, char* room, char* Day, char* Hour) {
    int slot = hash2(course);
    CRDH* CRDHCurr = CRDHHash->lists[slot];
    if (CRDHCurr == NULL) {
        CRDHHash->lists[slot] = makeCRDH(course, room, Day, Hour);
        return;
    }
    CRDH* prev = CRDHCurr;
    while (CRDHCurr != NULL) {
        prev = CRDHCurr;
        CRDHCurr = CRDHCurr->nextCRDH;
    }
    prev->nextCRDH = makeCRDH(course, room, Day, Hour);
}

void DumpCRDH(CRDHList* table) {
    printf("COURSE\tROOM\t\tDAY\tHOUR\n");
    for (int i = 0; i < 50; i++) {
        if (table->lists[i] != NULL) {
            CRDH* curr = table->lists[i];
            while (curr != NULL) {
                printf("%s\t%s\t%s\t%s\n", curr->course, curr->room, curr->Day, curr->Hour);
                curr = curr->nextCRDH;
            }
        }
    }
}


CRDHList* JointCRDH(CRList* CRHash, CDHList* CDHHash) {
    CRDHList* Hashtableout = CRDH_Create();
    for (int i = 0; i < 50; i++) {
        CDH* CDHv = CDHHash->lists[i];
        while (CDHv != NULL) {
            int slot = hash2(CDHv->course);
            CR* CRr = CRHash->lists[slot];
            while (CRr != NULL) {
                insert_CRDH(Hashtableout, CRr->course, CRr->Room, CDHv->Day, CDHv->Hour);
                CRr = CRr->nextCR;
            }
            CDHv = CDHv->nextCDH;
        }
    }
    return Hashtableout;
}

void Projection_CRDH(CRDHList* CRDHHash, char* type, char* type2) {
    int size1 = 0;
    for (int i = 0; i < 50; i++) {
        CRDH* curr = CRDHHash->lists[i];
        while (curr != NULL) {
            size1 += 1;
            curr = curr->nextCRDH;
        }
    }
    char** charList = (char**)malloc(sizeof(char*) * size1);
    char** charList2 = (char**)malloc(sizeof(char*) * size1);
    int index = 0;
    for (int k = 0; k < 50; k++) {
        CRDH* curr1 = CRDHHash->lists[k];
        while (curr1 != NULL) {
            if (strcmp(type, "course") == 0) {
                charList[index] = (char*)malloc(strlen(curr1->course) + 1);
                strcpy(charList[index], curr1->course);
                index++;
            }
            else if (strcmp(type, "room") == 0) {
                charList[index] = (char*)malloc(strlen(curr1->room) + 1);
                strcpy(charList[index], curr1->room);
                index++;
            }
            else if (strcmp(type, "day") == 0) {
                charList[index] = (char*)malloc(strlen(curr1->Day) + 1);
                strcpy(charList[index], curr1->Day);
                index++;
            }
            else if (strcmp(type, "hour") == 0) {
                charList[index] = (char*)malloc(strlen(curr1->Hour) + 1);
                strcpy(charList[index], curr1->Hour);
                index++;
            }
            curr1 = curr1->nextCRDH;
        }
    }
    int index2 = 0;
    for (int k = 0; k < 50; k++) {
        CRDH* curr2 = CRDHHash->lists[k];
        while (curr2 != NULL) {
            if (strcmp(type2, "course") == 0) {
                charList2[index2] = (char*)malloc(strlen(curr2->course) + 1);
                strcpy(charList2[index2], curr2->course);
                index2++;
            }
            else if (strcmp(type2, "room") == 0) {
                charList2[index2] = (char*)malloc(strlen(curr2->room) + 1);
                strcpy(charList2[index2], curr2->room);
                index2++;
            }
            else if (strcmp(type2, "day") == 0) {
                charList2[index2] = (char*)malloc(strlen(curr2->Day) + 1);
                strcpy(charList2[index2], curr2->Day);
                index2++;
            }
            else if (strcmp(type2, "hour") == 0) {
                charList2[index2] = (char*)malloc(strlen(curr2->Hour) + 1);
                strcpy(charList2[index2], curr2->Hour);
                index2++;
            }
            curr2 = curr2->nextCRDH;
        }
    }
    printf("Day\tHour\n");
    for (int j = 0; j < size1; j++) {
        printf("%s\t%s\n", charList[j], charList2[j]);
        free(charList[j]);
        free(charList2[j]);
    }

    free(charList);
    free(charList2);
}
CRDHList* Selection_CRDH(CRDHList* CRDHHash, char* Room) {
    CRDHList* newList = CRDH_Create();
    for (int i = 0; i < 50; i++) {
        CRDH* curr = CRDHHash->lists[i];
        while (curr != NULL) {
            if (strcmp(curr->room, Room) == 0) {
                insert_CRDH(newList, curr->course, curr->room, curr->Day, curr->Hour);
            }
            curr = curr->nextCRDH;
        }
    }
    return newList;
}

void JointOperation(CRList* CRHash, CDHList* CDHHash, char* Room, char* type1, char* type2) {
    CRDHList* CRDHHash = JointCRDH(CRHash, CDHHash);
    CRDHList* CRDHNew = Selection_CRDH(CRDHHash, Room);
    Projection_CRDH(CRDHNew, type1, type2);

    for (int i = 0; i < 50; i++) {
        if (CRDHHash->lists[i] != NULL) {
            freeCRDH(CRDHHash->lists[i]);
        }
        else {
            free(CRDHHash->lists[i]);
        }

        if (CRDHNew->lists[i] != NULL) {
            freeCRDH(CRDHNew->lists[i]);
        }
        else {
            free(CRDHNew->lists[i]);
        }
    }
    free(CRDHHash);
    free(CRDHNew);
}

void freeCRDH(CRDH* CRDHi) {
    if (CRDHi->nextCRDH == NULL) {
        free(CRDHi->course);
        free(CRDHi->Day);
        free(CRDHi->Hour);
        free(CRDHi->room);
        free(CRDHi);
        return;
    }
    else {
        free(CRDHi->course);
        free(CRDHi->Day);
        free(CRDHi->Hour);
        free(CRDHi->room);
        freeCRDH(CRDHi->nextCRDH);
        free(CRDHi);
    }
}

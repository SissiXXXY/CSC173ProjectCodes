#include <stdlib.h>
#include <stdio.h>
#include <sqlite3.h>
#include <string.h>

int main(void){
  FILE *fp = fopen("f.sql", "a");
  printf("Now Demonstrating the Extra Credit Question 3\n");
  printf("This Program asks User to enter desired Input until user is satisfied.\n");
  printf("The Program will run sqlite3 to answer user's all query at onece\n");
  printf("The Program will quary what grade did studentName get in Course Nam\n ");
  printf("Please Enter the desired Student Name: (Enter QUIT to quit)\n");
	char str[128];
	char str2[128];
	scanf("%[^\n]%*c", str);
	while (strcmp(str, "QUIT") != 0) {
		printf("Please Enter the Desire Course Name: \n");
		scanf("%[^\n]%*c", str2);
    fprintf(fp, "SELECT grade FROM CSG JOIN SNAP ON CSG.studentID=SNAP.studentID WHERE name=\"%s\" AND course=\"%s\";\n",str, str2);
		printf("Please Enter the desired Student Name: (Enter QUIT to quit)\n");
		scanf("%[^\n]%*c", str);
	}
  system("sqlite3 --init f.sql");
  fclose(fp);
  return 0;
}

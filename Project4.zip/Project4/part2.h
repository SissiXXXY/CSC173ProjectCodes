void GradeStudentCourse(SNAPList* SNAPHash, CSGList* CSGHash, char* studentName, char* course);
void part2Repl(SNAPList* SNAPHash, CSGList* CSGHash, CPList* CPHash, CRList* CRHash, CDHList* CDHHash);
void StudentNameCourseHour(SNAPList* SNAPHash, CSGList* CSGHash, CDHList* CDHHash, char* studentname, char* day);


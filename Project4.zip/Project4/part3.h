CSGList* selection_CSG(CSGList* CSGHash, char* course);
CRDHList* JointCRDH(CRList* CRHash, CDHList* CDHHash);
void Projection_CSG(CSGList* CSGHash, char* type);
void DumpCRDH(CRDHList* table);

void Projection_CRDH(CRDHList* CRDHHash, char* type, char* type2);
CRDHList* Selection_CRDH(CRDHList* CRDHHash, char* Room);
void JointOperation(CRList* CRHash, CDHList* CDHHash, char* Room, char* type1, char* type2);
void freeCRDH(CRDH* CRDHi);

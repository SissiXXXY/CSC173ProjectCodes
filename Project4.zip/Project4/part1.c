#include "part1.h"
#include "part2.h"
#include "part3.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int HashSize = 50;
///////////////////////// FILE PROCESSING //////////////////////////////////////////////
void WriteSCG(CSGList *Hashtable, FILE* fptr) {
    fprintf(fptr,"SCG\n");
    fprintf(fptr,"StudentID\tCourse\tGrade\n");
    for (int i = 0; i < HashSize; i++) {
        if (Hashtable->lists[i] != NULL) {
            CSG* COut = Hashtable->lists[i];
            while (COut != NULL) {
                fprintf(fptr, "%d\t%s\t%s\n", COut->studentID, COut->Course, COut->grade);
                COut = COut->nextCSG;
            }
        }
    }
    //fprintf(fptr, "\n");
}

void WriteSNAP(SNAPList* Hashtable, FILE* fptr) {
    fprintf(fptr,"SNAP");
    fprintf(fptr,"StudentID\tName\tAddress\tPhone\n");
    for (int i = 0; i < HashSize; i++) {
        if (Hashtable->lists[i] != NULL) {
            SNAP* COut = Hashtable->lists[i];
            while (COut != NULL) {
                fprintf(fptr,"%d\t%s\t%s\t%s\n", COut->studentID, COut->Name, COut->Address, COut->phone);
                COut = COut->nextSNAP;
            }
        }
    }
    //fprintf(fptr, "\n");
}

void WriteCP(CPList* Hashtable, FILE* fptr) {
    fprintf(fptr,"CP");
    fprintf(fptr,"Course\tPrerequisite\n");
    for (int i = 0; i < HashSize; i++) {
        if (Hashtable->lists[i] != NULL) {
            CP* COut = Hashtable->lists[i];
            while (COut != NULL) {
                fprintf(fptr,"%s\t%s\n",COut->Course, COut->Prerequisite);
                COut = COut->nextCP;
            }
        }
    }
    //fprintf(fptr, "\n");
}

void WriteCDH(CDHList* Hashtable, FILE* fptr) {
    fprintf(fptr,"CDH");
    fprintf(fptr,"Course\tDay\tHour\n");
    for (int i = 0; i < HashSize; i++) {
        if (Hashtable->lists[i] != NULL) {
            CDH* COut = Hashtable->lists[i];
            while (COut != NULL) {
                fprintf(fptr,"%s\t%s\t%s\n",COut->course, COut->Day, COut->Hour);
                COut = COut->nextCDH;
            }
        }
    }
}

void WriteCR(CRList* Hashtable, FILE* fptr) {
    fprintf(fptr,"CR");
    fprintf(fptr,"Course\tRoom\n");
    for (int i = 0; i < HashSize; i++) {
        if (Hashtable->lists[i] != NULL) {
            CR* COut = Hashtable->lists[i];
            while (COut != NULL) {
                fprintf(fptr,"%s\t%s\n", COut->course, COut->Room);
                COut = COut->nextCR;
            }
        }
    }
    //fprintf(fptr, "\n");
}

void WriteFile(CSGList* CSGHash,SNAPList* SNAPHash,CPList* CPHash,CDHList* CDHHash,CRList* CRHash){
    FILE *fptr;
    fptr=fopen("database.txt", "w");

    WriteSCG(CSGHash,fptr);
    WriteSNAP(SNAPHash,fptr);
    WriteCP(CPHash,fptr);
    WriteCDH(CDHHash,fptr);
    WriteCR(CRHash,fptr);

    fclose(fptr);
}

void LoadSCG(FILE* fptr){
    CSGList* CSGHash = CSG_Create();
    char readID[100];
    int ID;
    char course[100];
    char grade[100];
    while(fscanf(fptr,"%s%s%s",readID,course,grade)!=EOF){
        if(strcmp(readID,"SNAP")!=0){
            ID=atoi(readID);
            Insert_CSG(CSGHash, ID, course, grade);
        }
        else{
            break;
        }
    }
}

void LoadSNAP(FILE* fptr){
    SNAPList* SNAPHash = SNAP_Create();
    char readID[100];
    int ID;
    char name[100];
    char address[100];
    char phone[100];
    while(fscanf(fptr,"%s%s%s%s",readID,name,address,phone)!=EOF){
        if(strcmp(readID,"CP")!=0){
            ID=atoi(readID);
            Insert_SNAP(SNAPHash, ID, name,address,phone);
        }
        else{
            break;
        }
    }
}

void LoadCP(FILE* fptr){
    CPList* CPHash = CP_Create();
    char course[100];
    char prereq[100];
    while(fscanf(fptr,"%s%s",course,prereq)!=EOF){
        if(strcmp(course,"CDH")!=0){
            Insert_CP(CPHash, course, prereq);
        }
        else{
            break;
        }
    }
}

void LoadCDH(FILE* fptr){
    CDHList* CDHHash = CDH_Create();
    char course[100];
    char day[100];
    char hour[100];
    while(fscanf(fptr,"%s%s%s",course,day,hour)!=EOF){
        if(strcmp(course,"CR")!=0){
            Insert_CDH(CDHHash, course, day, hour);
        }
        else{
            break;
        }
    }
}

void LoadCR(FILE* fptr){
    CRList* CRHash = CR_Create();
    char course[100];
    char room[100];
    while(fscanf(fptr,"%s%s",course,room)!=EOF){
        Insert_CR(CRHash, course, room);
    }
}

void LoadFile(){
    FILE *fptr;
    fptr=fopen("database.txt","r");

    LoadSCG(fptr);
    LoadSNAP(fptr);
    LoadCP(fptr);
    LoadCDH(fptr);
    LoadCR(fptr);

    fclose(fptr);
}

///////////////////////// Main Function //////////////////////////////////////////////
int main(void) {
    CSGList* CSGHash = CSG_Create();
    Insert_CSG(CSGHash, 12345, "CS101", "A");
    Insert_CSG(CSGHash, 67890, "CS101", "B");
    Insert_CSG(CSGHash, 12345, "EE200", "C");
    Insert_CSG(CSGHash, 22222, "EE200", "B+");
    Insert_CSG(CSGHash, 33333, "CS101", "A-");
    Insert_CSG(CSGHash, 67890, "PH100", "C+");

    SNAPList* SNAPHash = SNAP_Create();
    Insert_SNAP(SNAPHash, 12345, "C. Brown", "12 Apple St.", "555-1234");
    Insert_SNAP(SNAPHash, 67890, "L. Van Pelt", "34 Pear Ave.", "555-5678");
    Insert_SNAP(SNAPHash, 22222, "P. Patty", "56 Grape Blvd", "555-9999");

    CPList* CPHash = CP_Create();
    Insert_CP(CPHash, "CS101", "CS100");
    Insert_CP(CPHash, "EE200", "EE005");
    Insert_CP(CPHash, "CS120", "CS101");
    Insert_CP(CPHash, "CS121", "CS120");
    Insert_CP(CPHash, "CS205", "CS101");
    Insert_CP(CPHash, "CS206", "CS121");
    Insert_CP(CPHash, "CS206", "CS205");

    CDHList* CDHHash = CDH_Create();
    Insert_CDH(CDHHash, "CS101", "M", "9AM");
    Insert_CDH(CDHHash, "CS101", "W", "9AM");
    Insert_CDH(CDHHash, "CS101", "F", "9AM");
    Insert_CDH(CDHHash, "EE200", "Tu", "10AM");
    Insert_CDH(CDHHash, "EE200", "W", "1PM");
    Insert_CDH(CDHHash, "EE200", "Th", "10AM");

    CRList* CRHash = CR_Create();
    Insert_CR(CRHash, "CS101", "Turing Aud.");
    Insert_CR(CRHash, "EE200", "25 Ohm Hall");
    Insert_CR(CRHash, "PH100", "Newton Lab.");

    WriteFile(CSGHash,SNAPHash,CPHash,CDHHash,CRHash);
    //LoadFile();

    printf("lookup((CS101, 12345, *), Course-StudentID-Grade): ");
    lookup_CSG(CSGHash, 12345, "CS101", "*");

    printf("\n");
    printf("lookup((CS205, CS120), Course-Prerequisite): ");
    lookup_CP(CPHash, "CS205", "CS120");
    printf("\n");

    printf("delete((CS101, *), Course-Room)\n");
    printf("Defore Deletion: \n");
    DumpCR(CRHash);
    delete_CR(CRHash, "CS101", "*");
    printf("After Deletion: \n");
    DumpCR(CRHash);
    printf("\n");

    printf("insert((CS205, CS120), Course-Prerequisite): \n");
    printf("Before Insertion: \n");
    DumpCP(CPHash);
    Insert_CP(CPHash, "CS205", "CS120");
    printf("After Insertion: \n");
    DumpCP(CPHash);
    printf("\n");

    printf("insert((CS205, CS101), Course-Prerequisite): \n");
    printf("Before Insertion: \n");
    DumpCP(CPHash);
    Insert_CP(CPHash, "CS205", "CS101");
    printf("After Insertion: \n");
    DumpCP(CPHash);
    printf("\n");
    Insert_CR(CRHash, "CS101", "Turing Aud.");

    part2Repl(SNAPHash, CSGHash, CPHash, CRHash, CDHHash);
    printf("This Demontrate selection on CSG by selecting CS101\n");
    DumpCSG(selection_CSG(CSGHash, "CS101"));
    printf("\n");

    printf("This Demonstrat the Projection on (Slelction CS101 CSG)\n");
    Projection_CSG(selection_CSG(CSGHash, "CS101"), "studentid");
    printf("\n");

    printf("This Demonstrate the Joint Operation on CR and CDH\n");
    DumpCRDH(JointCRDH(CRHash, CDHHash));
    printf("\n");
    printf("This select the Tuples hav Room component TUring aud and project the Days and Hour of Turing Aud.\n");
    JointOperation(CRHash, CDHHash, "Turing Aud.", "day", "hour");
    printf("\n");


    /// FreeStuff
    for (int i = 0; i < 50; i++) {
        if (CSGHash->lists[i] != NULL) {
            freeCSG(CSGHash->lists[i]);
        }
        else {
            free(CSGHash->lists[i]);
        }

        if (SNAPHash->lists[i] != NULL) {
            freeSNAP(SNAPHash->lists[i]);
        }
        else {
            free(SNAPHash->lists[i]);
        }

        if (CPHash->lists[i] != NULL) {
            freeCP(CPHash->lists[i]);
        }
        else {
            free(CPHash->lists[i]);
        }

        if (CDHHash->lists[i] != NULL) {
            freeCDH(CDHHash->lists[i]);
        }
        else {
            free(CDHHash->lists[i]);
        }
        if (CRHash->lists[i] != NULL) {
            freeCR(CRHash->lists[i]);
        }else {
            free(CRHash->lists[i]);
        }
    }

    free(CSGHash);
    free(SNAPHash);
    free(CPHash);
    free(CDHHash);
    free(CRHash);
    return 0;
}

void freeCR(CR* CRi) {
    if (CRi->nextCR == NULL) {
        free(CRi->course);
        free(CRi);
        return;
    }
    else {
        free(CRi->course);
        free(CRi->Room);
        freeCR(CRi->nextCR);
        free(CRi);
    }
}

void freeCDH(CDH* CDHi) {
    if (CDHi->nextCDH == NULL) {
        free(CDHi->Day);
        free(CDHi->course);
        free(CDHi->Hour);
        free(CDHi);
        return;
    }
    else {
        free(CDHi->Day);
        free(CDHi->course);
        free(CDHi->Hour);
        freeCDH(CDHi->nextCDH);
        free(CDHi);
    }
}
void freeCP(CP* CPi) {
    if (CPi->nextCP == NULL) {
        free(CPi->Course);
        free(CPi->Prerequisite);
        free(CPi);
        return;
    }
    else {
        free(CPi->Course);
        free(CPi->Prerequisite);
        freeCP(CPi->nextCP);
        free(CPi);
    }
}

void freeSNAP(SNAP* Sf) {
    if (Sf->nextSNAP == NULL) {
        free(Sf->Address);
        free(Sf->Name);
        free(Sf->phone);
        free(Sf);
        return;
    }
    else {
        free(Sf->Address);
        free(Sf->Name);
        free(Sf->phone);
        freeSNAP(Sf->nextSNAP);
        free(Sf);
    }
}


void freeCSG(CSG* Cf) {
    if (Cf->nextCSG== NULL) {
        free(Cf->Course);
        free(Cf->grade);
        free(Cf);
        return;
    }
    else {
        free(Cf->Course);
        free(Cf->grade);
        freeCSG(Cf->nextCSG);
        free(Cf);
    }
}

////////////////////////////CSG//////////////////////////////////////////////
void DumpCSG(CSGList *Hashtable) {
    printf("StudentID\tCourse\tGrade\n");
    for (int i = 0; i < HashSize; i++) {
        if (Hashtable->lists[i] != NULL) {
            CSG* COut = Hashtable->lists[i];
            while (COut != NULL) {
                printf("%d\t%s\t%s\n", COut->studentID, COut->Course, COut->grade);
                COut = COut->nextCSG;
            }
        }
    }
}
CSGList* CSG_Create() {
    struct CSGList* HashTable = (CSGList*)malloc(sizeof(CSGList));
    HashTable->lists = (CSG**)malloc(sizeof(CSG*) * HashSize);
    for (int i = 0; i < HashSize; i++) {
        HashTable->lists[i] = NULL;
    }
    return HashTable;
}
CSG* makeCSG(int studentid, char* course, char* grade) {
    CSG* CSGOut = (CSG*)malloc(sizeof(CSG));
    CSGOut->Course = (char*)malloc(strlen(course) + 1);
    CSGOut->grade = (char*)malloc(strlen(grade) + 1);
    strcpy(CSGOut->Course, course);
    strcpy(CSGOut->grade, grade);
    CSGOut->studentID = studentid;
    CSGOut->nextCSG = NULL;
    return CSGOut;
}
void Insert_CSG(CSGList *HASTABLE, int studentID, char *course, char *grade) {
    //use studentid as hashkey
    int slot = hash1(studentID);
    CSG* CSGCurr = HASTABLE->lists[slot];

    //no collision
    if (CSGCurr == NULL) {
        HASTABLE->lists[slot] = makeCSG(studentID, course, grade);
        return;
    }

    CSG* prev = CSGCurr;

    while (CSGCurr != NULL) {
        if (strcmp(CSGCurr->grade, grade) == 0 && strcmp(CSGCurr->Course, course) == 0) {
            break;
        }
        else {
            prev = CSGCurr;
            CSGCurr = CSGCurr->nextCSG;
        }
    }
    prev->nextCSG = makeCSG(studentID, course, grade);
}
void lookup_CSG(CSGList* HashTable, int studentID, char* course, char* grade) {
    int slot = hash1(studentID);
    CSG* CSGCurr = HashTable->lists[slot];

    while (CSGCurr != NULL) {
        if(strcmp(course, "*") == 0) {
            if (strcmp(grade, "*") == 0) {
                printf("(%s, %d, %s)\n", CSGCurr->Course, studentID, CSGCurr->grade);
            }
            else{
                if (strcmp(CSGCurr->grade, grade) == 0) {
                    printf("(%s, %s, %d)\n", CSGCurr->Course, grade, studentID);
                }
            }
        }else{
            if (strcmp(CSGCurr->Course, course) == 0) {
                printf("(%s, %d, %s)\n", course, studentID, CSGCurr->grade);
            }
        }
        CSGCurr = CSGCurr->nextCSG;
    }
    printf("LookUp Complete\n");
}
void delete_CSG(CSGList* HashTable, int studentID, char* course, char* grade) {
    int slot = hash1(studentID);
    CSG* CSGCurr = HashTable->lists[slot];

    if (CSGCurr == NULL) {
        return;
    }
    CSG* CSGPrev = CSGCurr;
    int index = 0;

    while (CSGCurr != NULL) {
        if ((strcmp(CSGCurr->Course, course) == 0 && strcmp(CSGCurr->grade, grade) == 0)
            || (strcmp(CSGCurr->Course, course) == 0 && strcmp(grade, "*") == 0)
            || (strcmp(CSGCurr->grade, grade) == 0 && strcmp(course, "*") == 0)
            || (strcmp(course, "*") == 0 && strcmp(grade, "*") == 0)) {
            if (CSGCurr->nextCSG == NULL && index == 0) {
                HashTable->lists[slot] = NULL;
            }
            if(CSGCurr->nextCSG != NULL && index == 0) {
                HashTable->lists[slot] = CSGCurr->nextCSG;
            }
            if (CSGCurr->nextCSG == NULL && index != 0) {
                CSGPrev->nextCSG = NULL;
            }
            if (CSGCurr->nextCSG != NULL && index != 0) {
                CSGPrev->nextCSG = CSGCurr->nextCSG;
            }
        }
        CSGPrev = CSGCurr;
        CSGCurr = CSGPrev->nextCSG;

        index++;
    }
}

////////////////////////////SNAP//////////////////////////////////////////////
void DumpSNAP(SNAPList* Hashtable) {
    printf("StudentID\tName\tAddress\tPhone\n");
    for (int i = 0; i < HashSize; i++) {
        if (Hashtable->lists[i] != NULL) {
            SNAP* COut = Hashtable->lists[i];
            while (COut != NULL) {
                printf("%d\t%s\t%s\t%s\n	", COut->studentID, COut->Name, COut->Address, COut->phone);
                COut = COut->nextSNAP;
            }
        }
    }
}
SNAPList* SNAP_Create() {
    struct SNAPList* HashTable = (SNAPList*)malloc(sizeof(SNAPList));
    HashTable->lists = (SNAP**)malloc(sizeof(SNAP*) * HashSize);
    for (int i = 0; i < HashSize; i++) {
        HashTable->lists[i] = NULL;
    }
    return HashTable;
}
SNAP* makeSNAP(int studentID, char* Name, char* Address, char* Phone) {
    SNAP* SNAPOut = (SNAP*)malloc(sizeof(SNAP));
    SNAPOut->Address = (char*)malloc(strlen(Address) + 1);
    SNAPOut->Name = (char*)malloc(strlen(Name) + 1);
    SNAPOut->phone = (char*)malloc(strlen(Phone) + 1);

    strcpy(SNAPOut->Address, Address);
    strcpy(SNAPOut->Name, Name);
    strcpy(SNAPOut->phone, Phone);

    SNAPOut->studentID = studentID;
    SNAPOut->nextSNAP = NULL;
    return SNAPOut;
}
void Insert_SNAP(SNAPList* HashTable, int studentID, char* Name, char* Address, char* Phone) {
    int slot = hash1(studentID);
    SNAP* SNAPCurr = HashTable->lists[slot];

    if (SNAPCurr == NULL) {
        HashTable->lists[slot] = makeSNAP(studentID, Name, Address, Phone);
        return;
    }

    SNAP* prev = SNAPCurr;
    while (SNAPCurr != NULL) {
        if (strcmp(SNAPCurr->Name, Name) == 0 && strcmp(SNAPCurr->Address, Address) == 0 && strcmp(SNAPCurr->phone, Phone) == 0) {
            break;
        }
        else {
            prev = SNAPCurr;
            SNAPCurr = SNAPCurr->nextSNAP;
        }
    }

    prev->nextSNAP = makeSNAP(studentID, Name, Address, Phone);
}
void lookup_SNAP(SNAPList* HashTable, int studentID, char* Name, char* Address, char* Phone) {
    int slot = hash1(studentID);
    SNAP* SNAPCurr = HashTable->lists[slot];

    while (SNAPCurr != NULL) {
        if (strcmp(Name, "*") == 0) {
            if (strcmp(Address, "*") == 0) {
                if (strcmp(SNAPCurr->phone, Phone) == 0) {
                    printf("Name: %s, Address: %s\n", SNAPCurr->Name, SNAPCurr->Address);
                }
            }
            else if (strcmp(Phone, "*") == 0) {
                if (strcmp(SNAPCurr->Address, Address) == 0) {
                    printf("Name: %s, Phone: %s\n", SNAPCurr->Name, SNAPCurr->phone);
                }
            }
            else {
                if (strcmp(SNAPCurr->Address, Address) == 0 && strcmp(SNAPCurr->phone, Phone) == 0) {
                    printf("Name: %s\n", SNAPCurr->Name);
                }
            }
        }
        else if (strcmp(Address, "*") == 0) {
            if (strcmp(Phone, "*") == 0) {
                if (strcmp(SNAPCurr->Name, Name) == 0) {
                    printf("Phone: %s, Address: %s", SNAPCurr->phone, SNAPCurr->Name);
                }
            }
            else {
                if (strcmp(SNAPCurr->Name, Name) == 0 || strcmp(SNAPCurr->phone, Phone) == 0) {
                    printf("Address: %s", SNAPCurr->Address);
                }
            }
        }
        SNAPCurr = SNAPCurr->nextSNAP;
    }
    printf("LookUp Complete\n");
}
void delete_SNAP(SNAPList* HashTable, int studentID, char* Name, char* Address, char* Phone) {
    int slot = hash1(studentID);
    SNAP* SNAPCurr = HashTable->lists[slot];

    if (SNAPCurr == NULL) {
        return;
    }
    SNAP* SNAPPrev = SNAPCurr;
    int index = 0;
    while (SNAPCurr != NULL) {
        if (strcmp(SNAPCurr->Name, Name) == 0 && strcmp(SNAPCurr->Address, Address) == 0 && strcmp(SNAPCurr->phone, Phone) == 0) {
            if (SNAPCurr->nextSNAP == NULL && index == 0) {
                HashTable->lists[slot] = NULL;
            }
            if (SNAPCurr->nextSNAP != NULL && index == 0) {
                HashTable->lists[slot] = SNAPPrev->nextSNAP;
            }
            if (SNAPCurr->nextSNAP == NULL && index != 0) {
                SNAPPrev->nextSNAP = NULL;
            }
            if (SNAPCurr->nextSNAP != NULL && index != 0) {
                SNAPPrev->nextSNAP = SNAPPrev->nextSNAP;
            }
        }
        SNAPPrev = SNAPCurr;
        SNAPCurr = SNAPPrev->nextSNAP;
        index++;
    }
}


//////////////////////////////////CP/////////////////////////////////////////
void DumpCP(CPList* Hashtable) {
    printf("Course\tPrerequisite\n");
    for (int i = 0; i < HashSize; i++) {
        if (Hashtable->lists[i] != NULL) {
            CP* COut = Hashtable->lists[i];
            while (COut != NULL) {
                printf("%s\t%s\n",COut->Course, COut->Prerequisite);
                COut = COut->nextCP;
            }
        }
    }
}
CPList* CP_Create() {
    struct CPList* HashTable = (CPList*)malloc(sizeof(CPList));
    HashTable->lists = (CP**)malloc(sizeof(CP*) * HashSize);
    for (int i = 0; i < HashSize; i++) {
        HashTable->lists[i] = NULL;
    }
    return HashTable;
}
CP* makeCP(char* Course, char* Prerequisite) {
    CP* CPOut = (CP*)malloc(sizeof(CP));
    CPOut->Course = (char*)malloc(strlen(Course) + 1);
    CPOut->Prerequisite = (char*)malloc(strlen(Prerequisite) + 1);
    strcpy(CPOut->Course, Course);
    strcpy(CPOut->Prerequisite, Prerequisite);
    CPOut->nextCP = NULL;
    return CPOut;
}
void Insert_CP(CPList* HashTable, char* Course, char* Prerequisite) {
    int slot = hash2(Course);
    CP* CPCurr = HashTable->lists[slot];

    if (CPCurr == NULL) {
        HashTable->lists[slot] = makeCP(Course, Prerequisite);
        return;
    }

    CP* prev = CPCurr;
    while (CPCurr != NULL) {
        if (strcmp(CPCurr->Prerequisite, Prerequisite) == 0) {
            break;
        }
        else {
            prev = CPCurr;
            CPCurr = CPCurr->nextCP;
        }
    }

    prev->nextCP = makeCP(Course, Prerequisite);
}
void lookup_CP(CPList* HashTable, char* Course, char* Prerequisite) {
    int slot = hash2(Course);
    CP* CPCurr = HashTable->lists[slot];

    while (CPCurr != NULL) {
        if (strcmp(Prerequisite, "*") == 0) {
            printf("(%s, %s)", CPCurr->Course, CPCurr->Prerequisite);
        }
        else {
            if (strcmp(CPCurr->Prerequisite, Prerequisite) == 0) {
                printf("(%s, %s)", CPCurr->Course, CPCurr->Prerequisite);
            }
        }
        CPCurr = CPCurr->nextCP;
    }
    printf("\nLookup Complete\n");
}
void delete_CP(CPList* HashTable, char* Course, char* Prerequisite) {
    int slot = hash2(Course);
    CP* CPCurr = HashTable->lists[slot];

    if (CPCurr == NULL) {
        return;
    }
    CP* CPRev = CPCurr;
    int index = 0;
    while (CPCurr != NULL) {
        if (strcmp(CPCurr->Prerequisite, Prerequisite) || strcmp(Prerequisite, "*")) {
            if (CPCurr->nextCP == NULL && index == 0) {
                HashTable->lists[slot] = NULL;
            }
            if (CPCurr->nextCP != NULL && index == 0) {
                HashTable->lists[slot] = CPRev->nextCP;
            }
            if (CPCurr->nextCP == NULL && index != 0) {
                CPRev->nextCP = NULL;
            }
            if (CPCurr->nextCP != NULL && index != 0) {
                CPRev->nextCP = CPRev->nextCP;
            }
        }
        CPRev = CPCurr;
        CPCurr = CPRev -> nextCP;
        index++;
    }
}

///////////////////////////////////CDH/////////////////////////////////////////
void DumpCDH(CDHList* Hashtable) {
    printf("Course\tDay\tHour\n");
    for (int i = 0; i < HashSize; i++) {
        if (Hashtable->lists[i] != NULL) {
            CDH* COut = Hashtable->lists[i];
            while (COut != NULL) {
                printf("%s\t%s\t%s\n",COut->course, COut->Day, COut->Hour);
                COut = COut->nextCDH;
            }
        }
    }
}
CDHList* CDH_Create() {
    struct CDHList* HashTable = (CDHList*)malloc(sizeof(CDHList));
    HashTable->lists = (CDH**)malloc(sizeof(CP*) * HashSize);
    for (int i = 0; i < HashSize; i++) {
        HashTable->lists[i] = NULL;
    }
    return HashTable;
}
CDH* makeCDH(char* Course, char* Day, char* Hour) {
    CDH* CDHOut = (CDH*)malloc(sizeof(CDH));
    CDHOut->course = (char*)malloc(strlen(Course) + 1);
    CDHOut->Day = (char*)malloc(strlen(Day) + 1);
    CDHOut->Hour = (char*)malloc(strlen(Hour) + 1);
    strcpy(CDHOut->course, Course);
    strcpy(CDHOut->Day, Day);
    strcpy(CDHOut->Hour, Hour);
    CDHOut->nextCDH = NULL;
    return CDHOut;
}
void Insert_CDH(CDHList* HashTable, char* Course, char* Day, char* Hour) {
    int slot = hash2(Course);
    CDH* CDHCurr = HashTable->lists[slot];

    if (CDHCurr == NULL) {
        HashTable->lists[slot] = makeCDH(Course, Day, Hour);
        return;
    }

    CDH* prev = CDHCurr;
    while (CDHCurr != NULL) {
        prev = CDHCurr;
        CDHCurr = CDHCurr->nextCDH;
    }

    prev->nextCDH = makeCDH(Course, Day, Hour);
}
void lookup_CDH(CDHList* HashTable, char* Course, char* Day, char* Hour) {
    int slot = hash2(Course);
    CDH* CDHCurr = HashTable->lists[slot];

    while (CDHCurr != NULL) {
        if (strcmp(Day, "*") == 0) {
            if (strcmp(Hour, "*") == 0) {
                printf("Day: %s, Hour: %s", Day, Hour);
            }
            else {
                if (strcmp(CDHCurr->Hour, Hour) == 0) {
                    printf("Day: %s", Day);
                }
            }
        }
        else {
            if (strcmp(CDHCurr->Day, Day) == 0) {
                printf("Hour: %s", Hour);
            }
        }
        CDHCurr = CDHCurr->nextCDH;
    }
    printf("LookUp Complete\n");
}
void delete_CDH(CDHList* HashTable, char* Course, char* Day, char* Hour) {
    int slot = hash2(Course);
    CDH* CDHCurr = HashTable->lists[slot];

    if (CDHCurr == NULL) {
        return;
    }
    CDH* CDHPrev = CDHCurr;
    int index = 0;
    while (CDHCurr != NULL) {
        if ((strcmp(CDHCurr->Day, Day) == 0 && strcmp(CDHCurr->Hour, Hour) == 0)
            || (strcmp(CDHCurr->Day, Day) == 0 && strcmp(Hour, "*") == 0)
            || (strcmp(CDHCurr->Hour, Hour) == 0 && strcmp(Day, "*") == 0)
            || (strcmp(Day, "*") == 0 && strcmp(Hour, "*") == 0)) {
            if (CDHCurr->nextCDH == NULL && index == 0) {
                HashTable->lists[slot] = NULL;
            }
            if (CDHCurr->nextCDH != NULL && index == 0) {
                HashTable->lists[slot] = CDHPrev->nextCDH;
            }
            if (CDHCurr->nextCDH == NULL && index != 0) {
                CDHPrev->nextCDH = NULL;
            }
            if (CDHCurr->nextCDH != NULL && index != 0) {
                CDHPrev->nextCDH = CDHPrev->nextCDH;
            }
        }
        CDHPrev = CDHCurr;
        CDHCurr = CDHPrev ->nextCDH;
        index++;
    }
}


///////////////////////// CR//////////////////////////////////////////////
void DumpCR(CRList* Hashtable) {
    printf("Course\tRoom\n");
    for (int i = 0; i < HashSize; i++) {
        if (Hashtable->lists[i] != NULL) {
            CR* COut = Hashtable->lists[i];
            while (COut != NULL) {
                printf("%s\t%s\n", COut->course, COut->Room);
                COut = COut->nextCR;
            }
        }
    }
}
CRList* CR_Create() {
    struct CRList* Hashtable = (CRList*)malloc(sizeof(CRList));
    Hashtable->lists = (CR**)malloc(sizeof(CR*) * HashSize);
    for (int i = 0; i < HashSize; i++) {
        Hashtable->lists[i] = NULL;
    }
    return Hashtable;
}
CR* makeCR(char* Course, char* Room) {
    CR* CROut = (CR*)malloc(sizeof(CR));
    CROut->course = (char*)malloc(strlen(Course) + 1);
    CROut->Room = (char*)malloc(strlen(Course) + 1);
    strcpy(CROut->course, Course);
    strcpy(CROut->Room, Room);
    CROut->nextCR = NULL;
    return CROut;
}
void Insert_CR(CRList* HashTable, char* Course, char* Room) {
    int slot = hash2(Course);
    CR* CRCurr = HashTable->lists[slot];

    if (CRCurr == NULL) {
        HashTable->lists[slot] = makeCR(Course, Room);
        return;
    }

    CR* prev = CRCurr;
    while (CRCurr != NULL) {

        prev = CRCurr;
        CRCurr = CRCurr->nextCR;
    }
    prev->nextCR = makeCR(Course, Room);
}
void lookup_CR(CRList* HashTable, char* Course, char* Room) {
    int slot = hash2(Course);
    CR* CRCurr = HashTable->lists[slot];

    while (CRCurr != NULL) {
        if (strcmp(Room, "*") == 0) {
            printf("%s", CRCurr->Room);
        }
        else {
            if (strcmp(CRCurr->Room, Room) == 0) {
                printf("%s", CRCurr->Room);
            }
        }
        CRCurr = CRCurr->nextCR;
    }
}
void delete_CR(CRList* HashTable, char* Course, char* Room) {
    int slot = hash2(Course);
    CR* CRCurr = HashTable->lists[slot];

    if (CRCurr == NULL) {
        return;
    }
    CR* CRPrev = CRCurr;
    int index = 0;
    while (CRCurr != NULL) {
        if (strcmp(CRCurr->Room, Room) || strcmp(Room, "*")) {
            if (CRCurr->nextCR == NULL && index == 0) {
                HashTable->lists[slot] = NULL;
            }
            if (CRCurr->nextCR != NULL && index == 0) {
                HashTable->lists[slot] = CRPrev->nextCR;
            }
            if (CRCurr->nextCR == NULL && index != 0) {
                CRPrev->nextCR = NULL;
            }
            if (CRCurr->nextCR != NULL && index != 0) {
                CRPrev->nextCR = CRPrev->nextCR;
            }
        }
        CRPrev = CRCurr;
        CRCurr = CRPrev->nextCR;
        index++;
    }
}
// Hash Int
int hash1(int key) {
    int out = key % HashSize;
    return out;
}
// Hash Char;
int hash2(char *key) {
    char* inputKey = key;
    int stor = 0;
    for (int i = 0; i < strlen(inputKey); i++) {
        stor = stor + (int)inputKey[i];
    }
    int out = stor % HashSize;
    return out;
}




#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "part1.h"
#include "part2.h"

void part2Repl(SNAPList* SNAPHash, CSGList* CSGHash, CPList* CPHash, CRList* CRHash, CDHList* CDHHash) {
    printf("Now Demonstrating the Functionaility of Part 2:\n");
    printf("This Function answer the query of what grade did StudentName get in CourseName\n");
    printf("This Function is case sensitive and space sensitive, please enter the studentName and Course name correctly\n");
    printf("If the result is nothing, then there is no such a relation in the data base\n");
    printf("Please Enter the desired Student Name: (Enter QUIT to quit)\n");
    char str[128];
    char str2[128];
    scanf("%[^\n]%*c", str);
    while (strcmp(str, "QUIT") != 0) {
        printf("Please Enter the Desire Course Name: \n");
        scanf("%[^\n]%*c", str2);
        GradeStudentCourse(SNAPHash, CSGHash, str, str2);
        printf("Please Enter the desired Student Name: (Enter QUIT to quit)\n");
        scanf("%[^\n]%*c", str);
    }




    printf("This Function answer the query of where is StudentName at Time on Day\n");
    printf("This Function is case sensitive and space sensitive, please enter the studentName and Day correctly\n");
    printf("If the result is nothing, then there is no such a relation in the data base\n");
    printf("Please Enter the desired Student Name: (Enter QUIT to quit)\n");
    char str3[128];
    char str4[128];
    scanf("%[^\n]%*c", str3);
    while (strcmp(str3, "QUIT") != 0) {
        printf("Please Enter the Desire Day: \n");
        scanf("%[^\n]%*c", str4);
        StudentNameCourseHour(SNAPHash, CSGHash, CDHHash, str3, str4);
        printf("Please Enter the desired Student Name: (Enter QUIT to quit)\n");
        scanf("%[^\n]%*c", str3);
    }



}



void GradeStudentCourse(SNAPList* SNAPHash, CSGList* CSGHash, char* studentName, char* course ) {
    for (int i = 0; i < 50; i++) {
        if (SNAPHash->lists[i] != NULL) {
            SNAP* GenericSnap = SNAPHash->lists[i];
            while (GenericSnap != NULL) {/////For each tuple t in studentid-name-address-phone
                if (strcmp(GenericSnap->Name, studentName) == 0) { //// if t has studentName in its Component then begin
                    int id = GenericSnap->studentID; /// let i be the studentID component of tuple t;
                    for (int k = 0; k < 50; k++) {
                        if (CSGHash->lists[i] != NULL) {
                            CSG* GenericCSG = CSGHash->lists[i];
                            while (GenericCSG != NULL) { /// for each tuple s in course-studentid-grade do
                                if (strcmp(GenericCSG->Course, course) == 0 && GenericCSG->studentID == id) { ///if s has course compnent cs101 and studentid component i then
                                    printf("Grade is: %s\n", GenericCSG->grade); ////print the grade component of tuples
                                    return;
                                }
                                GenericCSG = GenericCSG->nextCSG;
                            }
                        }
                    }
                }
                GenericSnap = GenericSnap->nextSNAP;
            }
        }/////end
    }
}


void StudentNameCourseHour(SNAPList* SNAPHash, CSGList* CSGHash, CDHList* CDHHash, char* studentname, char* day) {
    for (int i = 0; i < 50; i++) {
        if (SNAPHash->lists[i] != NULL) {
            SNAP* GenericSnap = SNAPHash->lists[i];
            while (GenericSnap != NULL) {
                if (strcmp(GenericSnap->Name, studentname) == 0) {
                    for (int k = 0; k < 50; k++) {
                        if (CSGHash->lists[k] != NULL) {
                            CSG* GenericCSG = CSGHash->lists[i];
                            while (GenericCSG != NULL) {
                                char* courseName = GenericCSG->Course;
                                for (int j = 0; j < 50; j++) {
                                    CDH* GenericCDH = CDHHash->lists[j];
                                    while (GenericCDH != NULL) {
                                        if (strcmp(courseName, GenericCDH->course) == 0 && strcmp(day, GenericCDH->Day) == 0) {
                                            printf("Hour: %s", GenericCDH->Hour);
                                            return;
                                        }
                                        GenericCDH = GenericCDH->nextCDH;
                                    }
                                }
                                GenericCSG = GenericCSG->nextCSG;
                            }
                        }
                    }
                }
                GenericSnap = GenericSnap->nextSNAP;
            }
        }
    }
}

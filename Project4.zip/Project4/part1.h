typedef struct CSG CSG;
typedef struct CSGList CSGList;
typedef struct SNAP SNAP;
typedef struct SNAPList SNAPList;
typedef struct CP CP;
typedef struct CPList CPList;
typedef struct CDH CDH;
typedef struct CDHList CDHList;
typedef struct CR CR;
typedef struct CRList CRList;
typedef struct CRDH CRDH;
typedef struct CRDHList CRDHList;

struct CSG {
    char* Course;
    int studentID;
    char* grade;
    CSG* nextCSG;
};
struct CSGList {
    CSG** lists;
};

struct CRDH {
    char* course;
    char* room;
    char* Day;
    char* Hour;
    CRDH* nextCRDH;
};

struct CRDHList {
    CRDH** lists;
};

struct SNAP {
    int studentID;
    char* Name;
    char* Address;
    char* phone;
    SNAP* nextSNAP;
};
struct SNAPList {
    SNAP** lists;
};


struct CP {
    char* Course;
    char* Prerequisite;
    CP* nextCP;
};
struct CPList {
    CP** lists;
};


struct CDH {
    char* course;
    char* Day;
    char* Hour;
    CDH* nextCDH;
};
struct CDHList {
    CDH** lists;
};


struct CR {
    char* course;
    char* Room;
    CR* nextCR;
};
struct CRList {
    CR** lists;
};

CSGList* CSG_Create();
CSG* makeCSG(int studentID, char* course, char* grade);
void Insert_CSG(CSGList* HASTABLE, int studentID, char* course, char* grade);
void lookup_CSG(CSGList* HashTable, int studentID, char* course, char* grade);
void delete_CSG(CSGList* HashTable, int studentID, char* course, char* grade);
void DumpCSG(CSGList* Hastable);



SNAPList* SNAP_Create();
SNAP* makeSNAP(int studentID, char* Name, char* Address, char* Phone);
void Insert_SNAP(SNAPList* HashTable, int studentID, char* Name, char* Address, char* Phone);
void lookup_SNAP(SNAPList* HashTable, int studentID, char* Name, char* Address, char* Phone);
void delete_SNAP(SNAPList* HashTable, int studentID, char* Name, char* Address, char* Phone);
void DumpSNAP(SNAPList* Hashtable);



CPList* CP_Create();
CP* makeCP(char* Course, char* Prerequisite);
void Insert_CP(CPList* HashTable, char* Course, char* Prerequisite);
void lookup_CP(CPList* HashTable, char* Course, char* Prerequisite);
void delete_CP(CPList* HashTable, char* Course, char* Prerequisite);
void DumpCP(CPList* Hashtable);

CDHList* CDH_Create();
CDH* makeCDH(char* Course, char* Day, char* Hour);
void Insert_CDH(CDHList* HashTable, char* Course, char* Day, char* Hour);
void lookup_CDH(CDHList* HashTable, char* Course, char* Day, char* Hour);
void delete_CDH(CDHList* HashTable, char* Course, char* Day, char* Hour);


CRList* CR_Create();
CR* makeCR(char* Course, char* Room);
void Insert_CR(CRList* HashTable, char* Course, char* Room);
void lookup_CR(CRList* HashTable, char* Course, char* Room);
void delete_CR(CRList* HashTable, char* Course, char* Room);
void DumpCR(CRList* Hashtable);
int hash1(int key);
int hash2(char* key);

void freeCSG(CSG* Cf);
void freeSNAP(SNAP* Sf);
void freeCP(CP* CPi);
void freeCDH(CDH* CDHi);
void freeCR(CR* CRi);
/*
 * File: main.c
 * Creator: George Ferguson
 * Created: Mon Nov 28 14:11:17 2016
 * Time-stamp: <Tue Jul 17 16:02:29 EDT 2018 ferguson>
 */
#include <stdio.h>
#include <stdlib.h>
#include "Circuit.h"

/**
 * Two AND gates connected to make a 3-input AND circuit.
 */
/* Following are the offered sample code
 * static Circuit* and3_Circuit() {
    Boolean* x = new_Boolean(false);
    Boolean* y = new_Boolean(false);
    Boolean* z = new_Boolean(false);
    Boolean** inputs = new_Boolean_array(3);
    inputs[0] = x;
    inputs[1] = y;
    inputs[2] = z;

    Boolean* out = new_Boolean(false);
    Boolean** outputs = new_Boolean_array(1);
    outputs[0] = out;

    Gate* A1 = new_AndGate();
    Gate* A2 = new_AndGate();
    Gate** gates = new_Gate_array(2);
    gates[0] = A1;
    gates[1] = A2;

    Circuit *circuit = new_Circuit(3, inputs, 1, outputs, 2, gates);
    Circuit_connect(circuit, x, Gate_getInput(A1, 0));
    Circuit_connect(circuit, y, Gate_getInput(A1, 1));
    Circuit_connect(circuit, Gate_getOutput(A1), Gate_getInput(A2, 0));
    Circuit_connect(circuit, z, Gate_getInput(A2, 1));
    Circuit_connect(circuit, Gate_getOutput(A2), out);
    return circuit;
}*/



static Circuit* create_circuitA(){
    //Circuit A has 2 inputs, 3 gates, 1 output, 7 connections
    Boolean* x=new_Boolean(false);
    Boolean* y=new_Boolean(false);
    Boolean** inputs=new_Boolean_array(2);
    inputs[0]=x;
    inputs[1]=y;

    Boolean* out=new_Boolean(false);
    Boolean** outputs=new_Boolean_array(1);
    outputs[0]=out;

    Gate* A1=new_NandGate();
    Gate* A2=new_OrGate();
    Gate* A3=new_AndGate();
    Gate** gates=new_Gate_array(3);
    gates[0]=A1;
    gates[1]=A2;
    gates[2]=A3;

    Circuit* circuitA=new_Circuit(2, inputs, 1, outputs, 3, gates);
    Circuit_connect(circuitA, x, Gate_getInput(A1, 0));
    Circuit_connect(circuitA, x, Gate_getInput(A2, 0));
    Circuit_connect(circuitA, y, Gate_getInput(A1, 1));
    Circuit_connect(circuitA, y, Gate_getInput(A2, 1));
    Circuit_connect(circuitA, Gate_getOutput(A1), Gate_getInput(A3, 0));
    Circuit_connect(circuitA, Gate_getOutput(A2), Gate_getInput(A3, 1));
    Circuit_connect(circuitA, Gate_getOutput(A3), out);
    return circuitA;
}

static Circuit* create_circuitB(){
    //Circuit B has 3 inputs, 3 gates, 1 output, 7 connections
    Boolean* x=new_Boolean(false);
    Boolean* y=new_Boolean(false);
    Boolean* z=new_Boolean(false);
    Boolean** inputs=new_Boolean_array(3);
    inputs[0]=x;
    inputs[1]=y;
    inputs[2]=z;

    Boolean* out=new_Boolean(false);
    Boolean** outputs=new_Boolean_array(1);
    outputs[0]=out;

    Gate* A1=new_AndGate();
    Gate* A2=new_NandGate();
    Gate* A3=new_OrGate();
    Gate** gates=new_Gate_array(3);
    gates[0]=A1;
    gates[1]=A2;
    gates[2]=A3;

    Circuit* circuitB=new_Circuit(3, inputs, 1, outputs, 3, gates);
    Circuit_connect(circuitB, x, Gate_getInput(A1, 0));
    Circuit_connect(circuitB, y, Gate_getInput(A1, 1));
    Circuit_connect(circuitB, y, Gate_getInput(A2, 0));
    Circuit_connect(circuitB, z, Gate_getInput(A2, 1));
    Circuit_connect(circuitB, Gate_getOutput(A1), Gate_getInput(A3, 0));
    Circuit_connect(circuitB, Gate_getOutput(A2), Gate_getInput(A3, 1));
    Circuit_connect(circuitB, Gate_getOutput(A3), out);
    return circuitB;
}

static Circuit* create_circuitC(){
    //Circuit C has 3 inputs, 8 gates, 1 output, 14 connections
    Boolean* x=new_Boolean(false);
    Boolean* y=new_Boolean(false);
    Boolean* z=new_Boolean(false);
    Boolean** inputs=new_Boolean_array(3);
    inputs[0]=x;
    inputs[1]=y;
    inputs[2]=z;

    Boolean* out=new_Boolean(false);
    Boolean** outputs=new_Boolean_array(1);
    outputs[0]=out;

    Gate* A1=new_Inverter();
    Gate* A2=new_Inverter();
    Gate* A3=new_Inverter();
    Gate* A4=new_AndGate();
    Gate* A5=new_AndGate();
    Gate* A6=new_AndGate();
    Gate* A7=new_OrGate();
    Gate* A8=new_OrGate();
    Gate** gates=new_Gate_array(8);
    gates[0]=A1;
    gates[1]=A2;
    gates[2]=A3;
    gates[3]=A4;
    gates[4]=A5;
    gates[5]=A6;
    gates[6]=A7;
    gates[7]=A8;

    Circuit* circuitC=new_Circuit(3, inputs, 1, outputs, 8, gates);
    Circuit_connect(circuitC, x, Gate_getInput(A4, 0));
    Circuit_connect(circuitC, x, Gate_getInput(A3, 0));
    Circuit_connect(circuitC, y, Gate_getInput(A1, 0));
    Circuit_connect(circuitC, y, Gate_getInput(A5, 0));
    Circuit_connect(circuitC, z, Gate_getInput(A2, 0));
    Circuit_connect(circuitC, z, Gate_getInput(A6, 0));
    Circuit_connect(circuitC, Gate_getOutput(A1), Gate_getInput(A4, 1));
    Circuit_connect(circuitC, Gate_getOutput(A2), Gate_getInput(A5, 1));
    Circuit_connect(circuitC, Gate_getOutput(A3), Gate_getInput(A6, 1));
    Circuit_connect(circuitC, Gate_getOutput(A4), Gate_getInput(A7, 0));
    Circuit_connect(circuitC, Gate_getOutput(A5), Gate_getInput(A7, 1));
    Circuit_connect(circuitC, Gate_getOutput(A7), Gate_getInput(A8, 0));
    Circuit_connect(circuitC, Gate_getOutput(A6), Gate_getInput(A8, 1));
    Circuit_connect(circuitC, Gate_getOutput(A8), out);
    return circuitC;
}

static char* b2s(bool b) {
    return b ? "T" : "F";
}

static void test2In1Out(Circuit* circuit, bool in0, bool in1) { //2 input 1 output
    Circuit_setInput(circuit, 0, in0);
    Circuit_setInput(circuit, 1, in1);
    Circuit_update(circuit);
    bool out0 = Circuit_getOutput(circuit, 0);
    printf("%s %s -> %s\n", b2s(in0), b2s(in1), b2s(out0));
}

static void test3In1Out(Circuit* circuit, bool in0, bool in1, bool in2) { //3 input 1 output
    Circuit_setInput(circuit, 0, in0);
    Circuit_setInput(circuit, 1, in1);
    Circuit_setInput(circuit, 2, in2);
    Circuit_update(circuit);
    bool out0 = Circuit_getOutput(circuit, 0);
    printf("%s %s %s -> %s\n", b2s(in0), b2s(in1), b2s(in2), b2s(out0));
}

//extra credit part (for one-bit adder)
static char* b2i(bool b) {
    return b ? "1" : "0";
}

static void testBinaryInput(Circuit* circuit, bool in0, bool in1, bool in2) {
    Circuit_setInput(circuit, 0, in0);
    Circuit_setInput(circuit, 1, in1);
    Circuit_setInput(circuit, 2, in2);
    Circuit_update(circuit);
    bool out1 = Circuit_getOutput(circuit, 0);
    bool out2 = Circuit_getOutput(circuit, 1);
    printf("Output is: %s %s %s -> %s %s\n", b2i(in0), b2i(in1), b2i(in2), b2i(out1), b2i(out2));
}

//One single function to test all the combinations
static void sc(Circuit* cir, int xxx, bool bin){

    if((Circuit_numInputs(cir)==2)&&(bin==false)){ //2 input 1 output
        if(xxx==4){
            return;
        }
        test2In1Out(cir, (xxx>>1)&1, (xxx>>0)&1);
        sc(cir, xxx+1, bin);
    }
    else if((Circuit_numInputs(cir)==3)&&(bin==false)){ //3 input 1 output
        if(xxx==8){
            return;
        }
        test3In1Out(cir, (xxx>>2)&1, (xxx>>1)&1, (xxx>>0)&1);
        sc(cir, xxx+1, bin);
    }
    else if((Circuit_numInputs(cir)==3)&&(bin==true)){ //3 input 1 output one-bit Adder
        if(xxx==8){
            return;
        }
        testBinaryInput(cir, (xxx>>2)&1, (xxx>>1)&1, (xxx>>0)&1);
        sc(cir, xxx+1, bin);
    }
    else{
        printf("Errors occurred before this function\n");
    }
}

//One-bit adder (extra credit)
static Circuit* threebitAdder() {
	Boolean* x = new_Boolean(false);
	Boolean* y = new_Boolean(false);
	Boolean* z = new_Boolean(false);
	Boolean** inputs = new_Boolean_array(3);
	inputs[0] = x;
	inputs[1] = y;
	inputs[2] = z;
	Boolean* out1 = new_Boolean(false);
	Boolean* out2 = new_Boolean(false);
	Boolean** outputs = new_Boolean_array(2);
	outputs[0] = out1;
	outputs[1] = out2;

	Gate* I1 = new_Inverter();
	Gate* I2 = new_Inverter();
	Gate* I3 = new_Inverter();
	Gate* A1 = new_And3Gate();
	Gate* A2 = new_And3Gate();
	Gate* A3 = new_And3Gate();
	Gate* A4 = new_And3Gate();
	Gate* A5 = new_And3Gate();
	Gate* A6 = new_And3Gate();
	Gate* A7 = new_And3Gate();
	Gate* O1 = new_Or4Gate();
	Gate* O2 = new_Or4Gate();
	Gate** gates = new_Gate_array(12);
	gates[0] = I1;
	gates[1] = I2;
	gates[2] = I3;
	gates[3] = A1;
	gates[4] = A2;
	gates[5] = A3;
	gates[6] = A4;
	gates[7] = A5;
	gates[8] = A6;
	gates[9] = A7;
	gates[10] = O1;
	gates[11] = O2;

	Circuit* circuit = new_Circuit(3, inputs, 2, outputs, 12, gates);
	Circuit_connect(circuit, x, Gate_getInput(I1, 0));
	Circuit_connect(circuit, y, Gate_getInput(I2, 0));
	Circuit_connect(circuit, z, Gate_getInput(I3, 0));
	Circuit_connect(circuit, Gate_getOutput(I1), Gate_getInput(A1, 0));
	Circuit_connect(circuit, Gate_getOutput(I2), Gate_getInput(A1, 1));
	Circuit_connect(circuit, z, Gate_getInput(A1, 2));

	Circuit_connect(circuit, Gate_getOutput(I1), Gate_getInput(A2, 0));
	Circuit_connect(circuit, Gate_getOutput(I3), Gate_getInput(A2, 1));
	Circuit_connect(circuit, y, Gate_getInput(A2, 2));

	Circuit_connect(circuit, Gate_getOutput(I1), Gate_getInput(A3, 0));
	Circuit_connect(circuit, y, Gate_getInput(A3, 1));
	Circuit_connect(circuit, z, Gate_getInput(A3, 2));

	Circuit_connect(circuit, x, Gate_getInput(A4, 0));
	Circuit_connect(circuit, Gate_getOutput(I2), Gate_getInput(A4, 1));
	Circuit_connect(circuit, Gate_getOutput(I3), Gate_getInput(A4, 2));

	Circuit_connect(circuit, x, Gate_getInput(A5, 0));
	Circuit_connect(circuit, z, Gate_getInput(A5, 1));
	Circuit_connect(circuit, Gate_getOutput(I2), Gate_getInput(A5, 2));

	Circuit_connect(circuit, x, Gate_getInput(A6, 0));
	Circuit_connect(circuit, y, Gate_getInput(A6, 1));
	Circuit_connect(circuit, Gate_getOutput(I3), Gate_getInput(A6, 2));

	Circuit_connect(circuit, x, Gate_getInput(A7, 0));
	Circuit_connect(circuit, y, Gate_getInput(A7, 1));
	Circuit_connect(circuit, z, Gate_getInput(A7, 2));

	Circuit_connect(circuit, Gate_getOutput(A1), Gate_getInput(O1, 0));
	Circuit_connect(circuit, Gate_getOutput(A2), Gate_getInput(O1, 1));
	Circuit_connect(circuit, Gate_getOutput(A4), Gate_getInput(O1, 2));
	Circuit_connect(circuit, Gate_getOutput(A7), Gate_getInput(O1, 3));
	Circuit_connect(circuit, Gate_getOutput(A3), Gate_getInput(O2, 0));
	Circuit_connect(circuit, Gate_getOutput(A5), Gate_getInput(O2, 1));
	Circuit_connect(circuit, Gate_getOutput(A6), Gate_getInput(O2, 2));
	Circuit_connect(circuit, Gate_getOutput(A7), Gate_getInput(O2, 3));
	Circuit_connect(circuit, Gate_getOutput(O1), out1);
	Circuit_connect(circuit, Gate_getOutput(O2), out2);
	return circuit;
}




int main() {

    printf("CSC173 Project 5\n");
    printf("This project is done by Yao Xiao and Yuze Wang\n");
    printf("**************************************************\n");

    //Circuit_A
    Circuit* circuit_A = create_circuitA();
    printf("The circuit A [ (X NAND Y) AND (X OR Y) ]:\n");
    Circuit_dump(circuit_A);
    printf("\n");
    sc(circuit_A,0,false);
    //Answer for A
    //F F -> F
    //F T -> T
    //T F -> T
    //T T -> F

    //Circuit_B
    Circuit* circuit_B = create_circuitB();
    printf("The circuit B [ (X AND Y) OR (Y NAND Z) ]:\n");
    Circuit_dump(circuit_B);
    printf("\n");
    sc(circuit_B,0,false);
    //F F F -> T
    //F F T -> T
    //F T F -> T
    //F T T -> F
    //T F F -> T
    //T F T -> T
    //T T F -> T
    //T T T -> T

    //Circuit_C
    Circuit* circuit_C = create_circuitC();
    printf("The circuit C [ ((X AND (NOT Y)) OR (Y AND (NOT Z))) OR (Z AND (NOT X)) ]:\n");
    Circuit_dump(circuit_C);
    printf("\n");
    sc(circuit_C,0,false);
    //F F F -> F
    //F F T -> T
    //F T F -> T
    //F T T -> T
    //T F F -> T
    //T F T -> T
    //T T F -> T
    //T T T -> F

    Circuit* circuit1 = threebitAdder();
  	printf("The Three bit adder, return a two bit output:\n");
  	Circuit_dump(circuit1);
  	sc(circuit1,0,true);
    //Output is: 0 0 0 -> 0 0
    //Output is: 0 0 1 -> 1 0
    //Output is: 0 1 0 -> 1 0
    //Output is: 0 1 1 -> 0 1
    //Output is: 1 0 0 -> 1 0
    //Output is: 1 0 1 -> 0 1
    //Output is: 1 1 0 -> 0 1
    //Output is: 1 1 1 -> 1 1

    //free the circuits
  	Circuit_free(circuit1);
    Circuit_free(circuit_A);
    Circuit_free(circuit_B);
    Circuit_free(circuit_C);

    //system("pause");

}

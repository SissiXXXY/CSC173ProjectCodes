typedef struct StateTransform StateTransform;
typedef struct DFA DFA;

DFA* def_DFA_A();
DFA* def_DFA_B();
DFA* def_DFA_C();
DFA* def_DFA_D();
DFA* def_DFA_E();

int Run_Func_A(DFA* CurrentAutomaton, char inputString[]);
void DFASYSTEM();

typedef struct stateBehavior {
	char stringsuccess;
}stateBehavior;

//State Data structure
struct StateTransform {
	int currentState;
	stateBehavior currentBehavior;
	StateTransform* stateTrue;
	StateTransform* stateFalse;
};
// DFA Data Structure
struct DFA {
	//initial States
	StateTransform* initialStates;
	//Final States Faill
	StateTransform* FinalFaillStates;
	StateTransform* SucessState;
	//transition States
	StateTransform StateArr[];
};
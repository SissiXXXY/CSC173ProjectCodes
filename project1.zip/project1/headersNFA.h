
typedef struct stateSystemNFA stateSystemNFA;
typedef struct NFA NFA;

NFA* def_NFA_A();
NFA* def_NFA_B();
NFA* def_NFA_C();
NFA* def_NFA_D();
int Run_FUNC_B(NFA* CurrentNFA, char inputString[], int* sucessstate, int sizeofsucess);
int* SearchForMatchOccurence(char searchLetter, char* letterpool, int *sizeofarr);
void NFASYSTEM();

struct stateSystemNFA {
	int currentstate;
	//it record the double behavior of the certain input, i.e: b for q1 at state 1 can either stay at current state or go to next state
	//it can serve as single condition as well
	char* behavior;
};

//Index state2DArraay[n][0] mark the currentstate
//Index state2DArray[0][m] mark all the possible state0 can go to
struct NFA {
	stateSystemNFA** state2Darray;
};

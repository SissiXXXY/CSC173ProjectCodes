#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "headercon.h"
#include "headersDFA.h"
#include "headersNFA.h"

DFA* TranslateToDFA(NFA* inputMachine) {
	int statesize = inputMachine->state2Darray[0][0].currentstate;
	printf("size is: %d \n", statesize);
	struct DFA* DFAMachine = (DFA*)malloc(sizeof(DFA) + statesize * sizeof(StateTransform));
	DFAMachine->initialStates = (StateTransform*)malloc(sizeof(StateTransform));
	DFAMachine->initialStates->currentState = 0;
	//read through the key behavior
	for (int i = 1; i < statesize; i++) {
		DFAMachine->StateArr[i-1].currentState = inputMachine->state2Darray[i][0].currentstate;
		if (inputMachine->state2Darray[i][0].behavior == "") {
			//printf("This is empty");
			DFAMachine->StateArr[i-1].currentBehavior.stringsuccess = "";
			DFAMachine->StateArr[i-1].stateFalse = &(DFAMachine->StateArr[1]);
			DFAMachine->StateArr[i-1].stateTrue = &(DFAMachine->StateArr[1]);
		}
		else if (inputMachine->state2Darray[i][0].behavior == "abcedefghijklmnopqrstuvwxyz") {
			//printf("This contain everything ");
			DFAMachine->StateArr[i - 1].currentBehavior.stringsuccess = 'z';
			DFAMachine->StateArr[i - 1].stateFalse = &(DFAMachine->StateArr[i - 1]);
			DFAMachine->StateArr[i - 1].stateTrue = &(DFAMachine->StateArr[i - 1]);
		}
		else {
			for (int k = 0; k < strlen(inputMachine->state2Darray[i][0].behavior) + 1; k++) {
				//if the double behavior is detected

				//printf("The current state is: %d, and comparing with: %d \n", inputMachine->state2Darray[i][k].currentstate, inputMachine->state2Darray[i][0].currentstate);
				if (inputMachine->state2Darray[i][k].currentstate != inputMachine->state2Darray[i][0].currentstate) {
					DFAMachine->StateArr[i-1].currentBehavior.stringsuccess = inputMachine->state2Darray[i][0].behavior[k - 1];
					DFAMachine->StateArr[i-1].stateTrue = &(DFAMachine->StateArr[inputMachine->state2Darray[i][k].currentstate - 1]);
					//printf("recording: %c character, from state: %d \n", inputMachine->state2Darray[i][0].behavior[k-1], inputMachine->state2Darray[i][k].currentstate);
					break;
				}
				else {
					DFAMachine->StateArr[i-1].stateFalse = &(DFAMachine->StateArr[inputMachine->state2Darray[1][0].currentstate]);
				}

			}
		}
	}

	for (int i = 0; i < statesize-1; i++) {
		printf("At state %d     ", DFAMachine->StateArr[i].currentState);
		printf("The sucess behaviro is %c      ", DFAMachine->StateArr[i].currentBehavior);
		printf("The False state numer is %d    ", DFAMachine->StateArr[i].stateFalse->currentState);
		printf("The true state numer is %d\n", DFAMachine->StateArr[i].stateTrue->currentState);
	}
	return DFAMachine;
}


void TestCon() {
	char input[128];
	printf("Testing DFA the recognizes string ending in 'back'...............\n");
	printf("Enter an input\n");
	fgets(input, 128, stdin);
	NFA* pesudoDFAA = def_NFA_A();
	while (strcmp(input, "QUIT\n")) {
		if (Run_Func_A(TranslateToDFA(pesudoDFAA), input) == 5) {
			printf("True\n");
		}
		else {
			printf("False\n");
		}
		printf("Enter an input\n");
		fgets(input, 128, stdin);
	}
	free(pesudoDFAA);

	printf("Testing DFA the recognizes string contain 'back'...............\n");
	printf("Enter an input\n");
	fgets(input, 128, stdin);
	NFA* pesudoDFAB = def_NFA_B();
	while (strcmp(input, "QUIT\n")) {
		if (Run_Func_A(TranslateToDFA(pesudoDFAB), input) == 5) {
			printf("True\n");
		}
		else {
			printf("False\n");
		}
		printf("Enter an input\n");
		fgets(input, 128, stdin);
	}
	free(pesudoDFAB);
}

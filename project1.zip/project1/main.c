#include <stdio.h>
#include "headersDFA.h"
#include "headersNFA.h"
#include "headercon.h"


int main() {
	DFASYSTEM();
	NFASYSTEM();
	TestCon();
	return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "headersNFA.h"


void NFASYSTEM() {
	char input[128];

	printf("Testing NFA that recognizes string ending in 'back'.....................\n");
	printf("Enter an input\n");
	fgets(input, 128, stdin);
	NFA* a = def_NFA_A();
	int output1[1] = {4};
	while (strcmp(input, "QUIT\n")) {
		//printf("Testing Program...");
		if (Run_FUNC_B(a, input, output1, 1) == 1) {
			printf("True\n");
		}
		else {
			printf("False\n");
		}
		printf("Enter an input\n");
		fgets(input, 128, stdin);
	}
	free(a);

	printf("Testing NFA that recognizes string containing 'back'......................\n");
	printf("Enter an input\n");
	fgets(input, 128, stdin);
	NFA* b = def_NFA_B();
	int output2[1] = { 5 };
	while (strcmp(input, "QUIT\n")) {
		if (Run_FUNC_B(b, input, output2, 1) == 1) {
			printf("True\n");
		}
		else {
			printf("False\n");
		}
		printf("Enter an input\n");
		fgets(input, 128, stdin);
	}
	free(b);

	printf("Testing NFA that recognizes string containing more than one 'a, g, h, i, o, s, t, w' or more than 2 'n'\n");
	printf("Enter an input\n");
	fgets(input, 128, stdin);
	NFA* c = def_NFA_C();
	int output3[9] = { 3, 5, 7, 9, 11, 19, 15, 17, 20 };
	while (strcmp(input, "QUIT\n")) {
		if (Run_FUNC_B(c, input, output3, 9) == 1) {
			printf("True\n");
		}
		else {
			printf("False\n");
		}
		printf("Enter an input\n");
		fgets(input, 128, stdin);
	}
	free(c);

	printf("Testing NFA That recognizes string containing word 'meme'\n");
	printf("Enter an input\n");
	fgets(input, 128, stdin);
	NFA* d = def_NFA_D();
	int output4[1] = { 5 };
	while (strcmp(input, "QUIT\n")) {
		if (Run_FUNC_B(d, input, output4, 1) == 1) {
			printf("True\n");
		}
		else {
			printf("False\n");
		}
		printf("Enter an input\n");
		fgets(input, 128, stdin);
	}
	free(d);
}


//sucess is 4
NFA* def_NFA_A() {
	struct NFA* NFA_A = (NFA*)malloc(sizeof(NFA));
	NFA_A->state2Darray = (stateSystemNFA**)malloc(6 * sizeof(stateSystemNFA*));
	for (int i = 0; i < 6; i++) {
		NFA_A->state2Darray[i] = (stateSystemNFA*)malloc(27 * sizeof(stateSystemNFA));
	}
	//initial state
	NFA_A->state2Darray[0][0].currentstate = 6;


	//state marker: 1
	NFA_A->state2Darray[1][0].currentstate = 1;
	NFA_A->state2Darray[1][0].behavior = "bbacdefghijklmnopqrst";
	//possible states it could lead to
	NFA_A->state2Darray[1][1].currentstate = 1;
	NFA_A->state2Darray[1][2].currentstate = 2;
	for (int i = 3; i < 27; i++) {
		NFA_A->state2Darray[1][i].currentstate = 1;
	}

	//state marker: 2
	NFA_A->state2Darray[2][0].currentstate = 2;
	NFA_A->state2Darray[2][0].behavior = "a";
	NFA_A->state2Darray[2][1].currentstate = 3;

	//state marker: 3
	NFA_A->state2Darray[3][0].currentstate = 3;
	NFA_A->state2Darray[3][0].behavior = "c";
	NFA_A->state2Darray[3][1].currentstate = 4;

	//state marker: 4
	NFA_A->state2Darray[4][0].currentstate = 4;
	NFA_A->state2Darray[4][0].behavior = "k";
	NFA_A->state2Darray[4][1].currentstate = 5;
	
	//state marker: 5
	NFA_A->state2Darray[5][0].currentstate = 5;
	NFA_A->state2Darray[5][0].behavior = "";
	NFA_A->state2Darray[5][1].currentstate = 5;

	return NFA_A;
}
//sucess is 5
NFA* def_NFA_B() {
	//sucess is 5
	struct NFA* NFA_B = (NFA*)malloc(sizeof(NFA));
	NFA_B->state2Darray = (stateSystemNFA**)malloc(6 * sizeof(stateSystemNFA*));
	for (int i = 0; i < 6; i++) {
		NFA_B->state2Darray[i] = (stateSystemNFA*)malloc(27 * sizeof(stateSystemNFA));
	}
	//points the amount of states
	NFA_B->state2Darray[0][0].currentstate = 6;
	//state marker: 1
	NFA_B->state2Darray[1][0].currentstate = 1;
	NFA_B->state2Darray[1][0].behavior = "bbacdefghijklmnopqrstuvwxyz";
	//possible states it could lead to
	NFA_B->state2Darray[1][1].currentstate = 1;
	NFA_B->state2Darray[1][2].currentstate = 2;
	for (int i = 3; i < 27; i++) {
		NFA_B->state2Darray[1][i].currentstate = 1;
	}

	//state marker: 2
	NFA_B->state2Darray[2][0].currentstate = 2;
	NFA_B->state2Darray[2][0].behavior = "a";
	NFA_B->state2Darray[2][1].currentstate = 3;

	//state marker: 3
	NFA_B->state2Darray[3][0].currentstate = 3;
	NFA_B->state2Darray[3][0].behavior = "c";
	NFA_B->state2Darray[3][1].currentstate = 4;

	//state marker: 4
	NFA_B->state2Darray[4][0].currentstate = 4;
	NFA_B->state2Darray[4][0].behavior = "k";
	NFA_B->state2Darray[4][1].currentstate = 5;

	//state marker 5
	NFA_B->state2Darray[5][0].currentstate = 5;
	NFA_B->state2Darray[5][0].behavior = "abcedefghijklmnopqrstuvwxyz";
	NFA_B->state2Darray[5][1].currentstate = 5;

	return NFA_B;
}
//sucess is 3 ,5, 7, 9, 11, 19, 15, 17, 19
NFA* def_NFA_C() {
	struct NFA* NFA_C = (NFA*)malloc(sizeof(NFA));
	NFA_C->state2Darray = (stateSystemNFA**)malloc(21 * sizeof(stateSystemNFA*));
	for (int i = 0; i < 21; i++) {
		NFA_C->state2Darray[i] = (stateSystemNFA*)malloc(34 * sizeof(stateSystemNFA));
	}

	NFA_C->state2Darray[0][0].currentstate = 21;
	NFA_C->state2Darray[1][0].currentstate = 1;
	NFA_C->state2Darray[1][0].behavior = "wwaasshhiinnggttoobcdefjklmopqrsuvxyz";
	NFA_C->state2Darray[1][1].currentstate = 1;
	NFA_C->state2Darray[1][2].currentstate = 2; // state w

	NFA_C->state2Darray[1][3].currentstate = 1;
	NFA_C->state2Darray[1][4].currentstate = 4; // state a

	NFA_C->state2Darray[1][5].currentstate = 1;
	NFA_C->state2Darray[1][6].currentstate = 6; // state s

	NFA_C->state2Darray[1][7].currentstate = 1;
	NFA_C->state2Darray[1][8].currentstate = 8; // state h

	NFA_C->state2Darray[1][9].currentstate = 1;
	NFA_C->state2Darray[1][10].currentstate = 10; // state i

	NFA_C->state2Darray[1][11].currentstate = 1;
	NFA_C->state2Darray[1][12].currentstate = 12; // state n

	NFA_C->state2Darray[1][13].currentstate = 1;
	NFA_C->state2Darray[1][14].currentstate = 14; // state g

	NFA_C->state2Darray[1][15].currentstate = 1;
	NFA_C->state2Darray[1][16].currentstate = 16; // state t

	NFA_C->state2Darray[1][17].currentstate = 1;
	NFA_C->state2Darray[1][18].currentstate = 18; // state o

	for (int i = 19; i < 34; i++) {
		NFA_C->state2Darray[1][i].currentstate = 1;
	}
	///////////////////////////////////////////////////////////////
	//W
	NFA_C->state2Darray[2][0].currentstate = 2;
	NFA_C->state2Darray[2][0].behavior = "w";
	NFA_C->state2Darray[2][1].currentstate = 3;
	NFA_C->state2Darray[3][0].currentstate = 3;
	NFA_C->state2Darray[3][0].behavior = "abcedefghijklmnopqrstuvwxyz";
	NFA_C->state2Darray[3][1].currentstate = 3; //success
	//A
	NFA_C->state2Darray[4][0].currentstate = 4;
	NFA_C->state2Darray[4][0].behavior = "a";
	NFA_C->state2Darray[4][1].currentstate = 5;
	NFA_C->state2Darray[5][0].currentstate = 5;
	NFA_C->state2Darray[5][0].behavior = "abcedefghijklmnopqrstuvwxyz";
	NFA_C->state2Darray[5][1].currentstate = 5; //success
	//S
	NFA_C->state2Darray[6][0].currentstate = 6;
	NFA_C->state2Darray[6][0].behavior = "s";
	NFA_C->state2Darray[6][1].currentstate = 7;
	NFA_C->state2Darray[7][0].currentstate = 7;
	NFA_C->state2Darray[7][0].behavior = "abcedefghijklmnopqrstuvwxyz";
	NFA_C->state2Darray[7][1].currentstate = 7; //success
	//H
	NFA_C->state2Darray[8][0].currentstate = 8;
	NFA_C->state2Darray[8][0].behavior = "h";
	NFA_C->state2Darray[8][1].currentstate = 9;
	NFA_C->state2Darray[9][0].currentstate = 9;
	NFA_C->state2Darray[9][0].behavior = "abcedefghijklmnopqrstuvwxyz";
	NFA_C->state2Darray[9][1].currentstate = 9; //success
	//I
	NFA_C->state2Darray[10][0].currentstate = 10;
	NFA_C->state2Darray[10][0].behavior = "i";
	NFA_C->state2Darray[10][1].currentstate = 11;
	NFA_C->state2Darray[11][0].currentstate = 11;
	NFA_C->state2Darray[11][0].behavior = "abcedefghijklmnopqrstuvwxyz";
	NFA_C->state2Darray[11][1].currentstate = 11; //success
	//N
	NFA_C->state2Darray[12][0].currentstate = 12;
	NFA_C->state2Darray[12][0].behavior = "n";
	NFA_C->state2Darray[12][1].currentstate = 13;
	NFA_C->state2Darray[13][0].currentstate = 13;
	NFA_C->state2Darray[13][0].behavior = "n";
	NFA_C->state2Darray[13][1].currentstate = 20;
	//extra n
	NFA_C->state2Darray[20][0].currentstate = 20;
	NFA_C->state2Darray[20][0].behavior = "abcedefghijklmnopqrstuvwxyz";
	NFA_C->state2Darray[20][1].currentstate = 20; //success
	//G
	NFA_C->state2Darray[14][0].currentstate = 14;
	NFA_C->state2Darray[14][0].behavior = "g";
	NFA_C->state2Darray[14][1].currentstate = 15;
	NFA_C->state2Darray[15][0].currentstate = 15;
	NFA_C->state2Darray[15][0].behavior = "abcedefghijklmnopqrstuvwxyz";
	NFA_C->state2Darray[15][1].currentstate = 15; //success
	//T
	NFA_C->state2Darray[16][0].currentstate = 16;
	NFA_C->state2Darray[16][0].behavior = "t";
	NFA_C->state2Darray[16][1].currentstate = 17;
	NFA_C->state2Darray[17][0].currentstate = 17;
	NFA_C->state2Darray[17][0].behavior = "abcedefghijklmnopqrstuvwxyz";
	NFA_C->state2Darray[17][1].currentstate = 17; //success
	//O
	NFA_C->state2Darray[18][0].currentstate = 18;
	NFA_C->state2Darray[18][0].behavior = "o";
	NFA_C->state2Darray[18][1].currentstate = 19;
	NFA_C->state2Darray[19][0].currentstate = 19;
	NFA_C->state2Darray[19][0].behavior = "abcedefghijklmnopqrstuvwxyz";
	NFA_C->state2Darray[19][1].currentstate = 19; //success

	return NFA_C;
	//3 ,5, 7, 9, 11, 19, 15, 17, 19
}
//sucess is 5
NFA* def_NFA_D() {
	//sucess is 5
	//String contain word "meme"

	NFA* NFA_D = (NFA*)malloc(sizeof(NFA));
	NFA_D->state2Darray = (stateSystemNFA**)malloc(6* sizeof(stateSystemNFA*));
	for (int i = 0; i < 6; i++) {
		NFA_D->state2Darray[i] = (stateSystemNFA*)malloc(27 * sizeof(stateSystemNFA));
	}
	NFA_D->state2Darray[0][0].currentstate = 0;

	NFA_D->state2Darray[1][0].currentstate = 1;
	NFA_D->state2Darray[1][0].behavior = "mmabcdefghijklnopqrstuvwxyz";
	NFA_D->state2Darray[1][1].currentstate = 1;
	NFA_D->state2Darray[1][2].currentstate = 2;
	for (int i = 3; i < 27; i++) {
		NFA_D->state2Darray[1][i].currentstate = 1;
	}

	NFA_D->state2Darray[2][0].currentstate = 2;
	NFA_D->state2Darray[2][0].behavior = "e";
	NFA_D->state2Darray[2][1].currentstate = 3;

	NFA_D->state2Darray[3][0].currentstate = 3;
	NFA_D->state2Darray[3][0].behavior = "m";
	NFA_D->state2Darray[3][1].currentstate = 4;

	NFA_D->state2Darray[4][0].currentstate = 4;
	NFA_D->state2Darray[4][0].behavior = "e";
	NFA_D->state2Darray[4][1].currentstate = 5;

	NFA_D->state2Darray[5][0].currentstate = 5;
	NFA_D->state2Darray[5][0].behavior = "abcdefghijklmnopqrstuvwxyz";
	NFA_D->state2Darray[5][1].currentstate = 5;
	return NFA_D;
}
int Run_FUNC_B(NFA* CurrentNFA, char inputString[], int* sucessstate, int sizeofsucess) {
	int currenticker = 1;
	int resultarr[128];
	int count = 0;
	int loopsize = strlen(inputString) - 1;

	//loop through the size of input
	for (int i = 0; i < loopsize; i++) {
		//if the character that is currently reading matches the behavior, store a behvaiors position in an array
		//i.e if bhevaior = abbc, reading character is b, then the array is = 1 2;
		//printf("I'm reading: %c\n", inputString[i]);
		int looptime = 0;
		int* occurence = SearchForMatchOccurence(inputString[i], CurrentNFA->state2Darray[currenticker][0].behavior, &looptime);
		//loop through the array(behaviors position)
		//////////////////////////////////////////////////////////
		/////////////////////////////////////////////////////////
		for (int j = 0; j < looptime; j++) {
			//match the behaviors with the all the states, retrive the possible state this character can leads to from state[currentticker]
			//
			//if the possible state is not the current state (not doing a loop)
			if (CurrentNFA->state2Darray[currenticker][occurence[j] + 1].currentstate != currenticker) {
				currenticker = CurrentNFA->state2Darray[currenticker][occurence[j] + 1].currentstate;
				//enters a while loop, match the remain state with remain input
				//create a pesudo counter
				int pesudoC = i+1;
				//creat a int array later can be append into main array depend if reached NULL state or not
				int* intarr = (int*)calloc((loopsize - pesudoC - 1), sizeof(int));
				int counterforintarr = 0;
				int truefalsecounter = 1;
				while (pesudoC < loopsize) {
					//printf("Hello, current number is: %d, and loopsize is: %d\n", pesudoC, loopsize);
					int findallnum = 0;
					for (int b = 0; b < strlen(CurrentNFA->state2Darray[currenticker][0].behavior); b++) {
						//printf("We are trying to match %c with %c\n", CurrentNFA->state2Darray[currenticker][0].behavior[b], inputString[pesudoC]);
						if (CurrentNFA->state2Darray[currenticker][0].behavior[b] == inputString[pesudoC]) {
							findallnum = 1;
							intarr[counterforintarr] = CurrentNFA->state2Darray[currenticker][1].currentstate;
							currenticker = CurrentNFA->state2Darray[currenticker][1].currentstate;
							//printf("this is a sucess!\n");
							counterforintarr++;
							break;
						}
					}
					if(findallnum == 0) {
						//reached NULL state, trash the int array
						//printf("It failled!\n");
						truefalsecounter = 0;
						break;
					}
					pesudoC++;
				}
				if (truefalsecounter == 1) {
					for (int a = 0; a < counterforintarr; a++) {
						//printf("I'm entering data into the result array!, result: %d\n", intarr[a]);
						resultarr[count] = intarr[a];
						count++;
					}
				}

				//printf("current ticker is %d", currenticker);
				//reset
				currenticker = 1;
			}
			else {
				resultarr[count] = CurrentNFA->state2Darray[currenticker][occurence[j] + 1].currentstate;
				count++;
			}
		}
		/////////////////////////////////////////////////////////////////////
		/////////////////////////////////////////////////////////////////////
	}
	for (int f = 0; f < count; f++) {
		//printf("%d ", resultarr[f]);
		for (int k = 0; k < sizeofsucess; k++) {
			//printf("%d \n", sucessstate[k]);
			if (resultarr[f] == sucessstate[k]) {
				return 1;
			}
		}
	}
	return 0;
}

int* SearchForMatchOccurence(char searchLetter, char* letterpool, int *sizeofarr) {
	int size = 0;
	for (int i = 0; i < strlen(letterpool); i++) {
		if (searchLetter == letterpool[i]) {
			size++;
			//printf("Ouccrence happened at current letter %c, the ouccrence index is: %d\n", searchLetter, i);
		}
	}
	int index = 0;
	if (size != 0) {
		int* output = (int*)calloc(size, sizeof(int));
		for (int i = 0; i < strlen(letterpool); i++) {
			if (searchLetter == letterpool[i]) {
				output[index] = i;
				//printf("inputing.... at index: %d, value: %d\n", index, i);
				index++;
			}
		}
		*sizeofarr = size;
		return output;
	}
	else {
		int* output = (int*)calloc(1, sizeof(int));
		output[0] = -1;
		*sizeofarr = 0;
		return output;
	}
}
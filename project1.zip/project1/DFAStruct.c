#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "headersDFA.h"


//main 1
void DFASYSTEM() {
	char input[128];
	printf("The Following Program Demonstrated the capability of the DFA strcuture\n");
	printf("To test the next question, simply enter QUIT\n");
	printf("CSC173 Project 1 by Yuze Wang and Yao Xiao\n");
	printf("Testing DFA that recognizes exactly 'Turing'\n");
	printf("Enter an input\n");
	fgets(input, 128, stdin);
	DFA* Q1 = def_DFA_A();
	while (strcmp(input, "QUIT\n")) {
		int a = Run_Func_A(Q1, input);
		if (a == 7|| a == 99) {
			printf("True\n");
		}
		else {
			printf("False\n");
		}
		printf("Enter an input\n");
		fgets(input, 128, stdin);
	}
	free(Q1);

	printf("Testing DFA that recognizes string starts with 4 4's... \n");
	printf("Enter an input\n");
	fgets(input, 128, stdin);
	DFA* Q2 = def_DFA_B();
	while (strcmp(input, "QUIT\n")) {
		int a = Run_Func_A(Q2, input);
		if (a == 99) {
			printf("True\n");
		}
		else {
			printf("False\n");
		}
		printf("Enter an input\n");
		fgets(input, 128, stdin);
	}
	free(Q2);
	printf("Testing DFA that recognizes string with odd number of 1's.... \n");
	printf("Enter an input\n");
	fgets(input, 128, stdin);
	DFA* Q3 = def_DFA_C();
	while (strcmp(input, "QUIT\n")) {
		int a = Run_Func_A(Q3, input);
		if (a == 2) {
			printf("True\n");
		}
		else {
			printf("False\n");
		}
		printf("Enter an input\n");
		fgets(input, 128, stdin);
	}
	free(Q3);

	printf("Testing DFA that recognizes string with odd number of 1's and even number of 0's......\n");
	printf("Enter an input\n");
	fgets(input, 128, stdin);
	DFA* Q4 = def_DFA_D();
	while (strcmp(input, "QUIT\n")) {
		int a = Run_Func_A(Q4, input);
		if (a == 4) {
			printf("True\n");
		}
		else {
			printf("False\n");
		}
		printf("Enter an input\n");
		fgets(input, 128, stdin);
	}
	free(Q4);

	printf("Testing DFA that recognizes strings contain 'Hello'......\n");
	printf("Enter an input\n");
	fgets(input, 128, stdin);
	DFA* Q5 = def_DFA_E();
	while (strcmp(input, "QUIT\n")) {
		int a = Run_Func_A(Q5, input);
		if (a == 99) {
			printf("True\n");
		}
		else {
			printf("False\n");
		}
		printf("Enter an input\n");
		fgets(input, 128, stdin);
	}

}
//State 7/99 is True Everything else is false
DFA* def_DFA_A() {
	//initialize the DFA
	struct DFA* DFA_Turing = (DFA*)malloc(sizeof(DFA) + 7 * sizeof(StateTransform));

	//initial Number is [0] (this is not the index of the array but it mark the beggining of all state array)
	//if the initial States detect char 'T', trainsition to state Arr;  (RE-referencing to a memory address)
	//if the initial States detect everything else, Jump Straight to Fail; (already a memory address, no need to RE-refernce)

	DFA_Turing->FinalFaillStates = (StateTransform*)malloc(sizeof(StateTransform));
	DFA_Turing->FinalFaillStates->currentState = -1;

	DFA_Turing->SucessState = (StateTransform*)malloc(sizeof(StateTransform));
	DFA_Turing->SucessState->currentState = 99;

	DFA_Turing->initialStates = (StateTransform*)malloc(sizeof(StateTransform));
	DFA_Turing->initialStates->currentState = 0;

	//First State Scann for Letter T
	DFA_Turing->StateArr[0].currentState = 1;
	DFA_Turing->StateArr[0].currentBehavior.stringsuccess = 'T';
	DFA_Turing->StateArr[0].stateTrue = &(DFA_Turing->StateArr[1]);
	DFA_Turing->StateArr[0].stateFalse = DFA_Turing->FinalFaillStates;

	//Second State Scann for Letter U
	DFA_Turing->StateArr[1].currentState = 2;
	DFA_Turing->StateArr[1].currentBehavior.stringsuccess = 'u';
	DFA_Turing->StateArr[1].stateTrue = &(DFA_Turing->StateArr[2]);
	DFA_Turing->StateArr[1].stateFalse = DFA_Turing->FinalFaillStates;

	//Third State Scann for Letter R
	DFA_Turing->StateArr[2].currentState = 3;
	DFA_Turing->StateArr[2].currentBehavior.stringsuccess = 'r';
	DFA_Turing->StateArr[2].stateTrue = &(DFA_Turing->StateArr[3]);
	DFA_Turing->StateArr[2].stateFalse = DFA_Turing->FinalFaillStates;

	//Fourth State Scann for letter I
	DFA_Turing->StateArr[3].currentState = 4;
	DFA_Turing->StateArr[3].currentBehavior.stringsuccess = 'i';
	DFA_Turing->StateArr[3].stateTrue = &(DFA_Turing->StateArr[4]);
	DFA_Turing->StateArr[3].stateFalse = DFA_Turing->FinalFaillStates;

	//Fifth State Scann for letter N
	DFA_Turing->StateArr[4].currentState = 5;
	DFA_Turing->StateArr[4].currentBehavior.stringsuccess = 'n';
	DFA_Turing->StateArr[4].stateTrue = &(DFA_Turing->StateArr[5]);
	DFA_Turing->StateArr[4].stateFalse = DFA_Turing->FinalFaillStates;

	//Sixth State Scann for letter G
	DFA_Turing->StateArr[5].currentState = 6;
	DFA_Turing->StateArr[5].currentBehavior.stringsuccess = 'g';
	DFA_Turing->StateArr[5].stateTrue = &(DFA_Turing->StateArr[6]);
	DFA_Turing->StateArr[5].stateFalse = DFA_Turing->FinalFaillStates;

	//if read anything, fail
	DFA_Turing->StateArr[6].currentState = 7;
	DFA_Turing->StateArr[6].currentBehavior.stringsuccess = (char)0;
	DFA_Turing->StateArr[6].stateTrue = DFA_Turing->SucessState;
	DFA_Turing->StateArr[6].stateFalse = DFA_Turing->FinalFaillStates;

	return DFA_Turing;
}
//State 99 is true
DFA* def_DFA_B() {
	//initialize the data structure
	struct DFA* DFA_QB = (DFA*)malloc(sizeof(DFA) + 5 * sizeof(StateTransform));

	DFA_QB->FinalFaillStates = (StateTransform*)malloc(sizeof(StateTransform));
	DFA_QB->FinalFaillStates->currentState = -1;

	DFA_QB->SucessState = (StateTransform*)malloc(sizeof(StateTransform));
	DFA_QB->SucessState->currentState = 99;
	DFA_QB->SucessState->stateFalse = DFA_QB->SucessState;

	DFA_QB->initialStates = (StateTransform*)malloc(sizeof(StateTransform));
	DFA_QB->initialStates->currentState = 0;

	DFA_QB->StateArr[0].currentState = 1;
	DFA_QB->StateArr[0].currentBehavior.stringsuccess = '4';
	DFA_QB->StateArr[0].stateTrue = &(DFA_QB->StateArr[1]);
	DFA_QB->StateArr[0].stateFalse = DFA_QB->FinalFaillStates;

	DFA_QB->StateArr[1].currentState = 2;
	DFA_QB->StateArr[1].currentBehavior.stringsuccess = '4';
	DFA_QB->StateArr[1].stateTrue = &(DFA_QB->StateArr[2]);
	DFA_QB->StateArr[1].stateFalse = DFA_QB->FinalFaillStates;

	DFA_QB->StateArr[2].currentState = 3;
	DFA_QB->StateArr[2].currentBehavior.stringsuccess = '4';
	DFA_QB->StateArr[2].stateTrue = &(DFA_QB->StateArr[3]);
	DFA_QB->StateArr[2].stateFalse = DFA_QB->FinalFaillStates;

	DFA_QB->StateArr[3].currentState = 4;
	DFA_QB->StateArr[3].currentBehavior.stringsuccess = '4';
	DFA_QB->StateArr[3].stateTrue = DFA_QB->SucessState;
	DFA_QB->StateArr[3].stateFalse = DFA_QB->FinalFaillStates;

	return DFA_QB;
}
//state 2 is True
DFA* def_DFA_C() {
	struct DFA* DFA_QC = (DFA*)malloc(sizeof(DFA) + 3 * sizeof(StateTransform));

	DFA_QC->initialStates = (StateTransform*)malloc(sizeof(StateTransform));
	DFA_QC->initialStates->currentState = 0;

	DFA_QC->StateArr[0].currentState = 1;
	DFA_QC->StateArr[0].currentBehavior.stringsuccess = '1';
	DFA_QC->StateArr[0].stateTrue = &(DFA_QC->StateArr[1]);
	DFA_QC->StateArr[0].stateFalse = &(DFA_QC->StateArr[0]);

	DFA_QC->StateArr[1].currentState = 2; //true
	DFA_QC->StateArr[1].currentBehavior.stringsuccess = '1';
	DFA_QC->StateArr[1].stateTrue = &(DFA_QC->StateArr[2]);
	DFA_QC->StateArr[1].stateFalse = &(DFA_QC->StateArr[1]);

	DFA_QC->StateArr[2].currentState = 3;
	DFA_QC->StateArr[2].currentBehavior.stringsuccess = '1';
	DFA_QC->StateArr[2].stateTrue = &(DFA_QC->StateArr[1]);
	DFA_QC->StateArr[2].stateFalse = &(DFA_QC->StateArr[2]);


	return DFA_QC;
}
//state 4 is true
DFA* def_DFA_D() {
	struct DFA* DFA_QD = (DFA*)malloc(sizeof(DFA) + 4 * sizeof(StateTransform));

	DFA_QD->initialStates = (StateTransform*)malloc(sizeof(StateTransform));
	DFA_QD->initialStates->currentState = 0;

	DFA_QD->StateArr[0].currentState = 1;
	DFA_QD->StateArr[0].currentBehavior.stringsuccess = '0';
	DFA_QD->StateArr[0].stateTrue = &(DFA_QD->StateArr[1]);
	DFA_QD->StateArr[0].stateFalse = &(DFA_QD->StateArr[3]);

	DFA_QD->StateArr[1].currentState = 2;
	DFA_QD->StateArr[1].currentBehavior.stringsuccess = '0';
	DFA_QD->StateArr[1].stateTrue = &(DFA_QD->StateArr[0]);
	DFA_QD->StateArr[1].stateFalse = &(DFA_QD->StateArr[2]);

	DFA_QD->StateArr[2].currentState = 3;
	DFA_QD->StateArr[2].currentBehavior.stringsuccess = '0';
	DFA_QD->StateArr[2].stateTrue = &(DFA_QD->StateArr[3]);
	DFA_QD->StateArr[2].stateFalse = &(DFA_QD->StateArr[1]);

	DFA_QD->StateArr[3].currentState = 4;
	DFA_QD->StateArr[3].currentBehavior.stringsuccess = '0';
	DFA_QD->StateArr[3].stateTrue = &(DFA_QD->StateArr[2]);
	DFA_QD->StateArr[3].stateFalse = &(DFA_QD->StateArr[0]);
	return DFA_QD;
}
//state 99 is true
DFA* def_DFA_E() {
	//custom DFA
	//Accept String Contain Hello

	struct DFA* DFA_QE = (DFA*)malloc(sizeof(DFA_QE) + 5 * sizeof(StateTransform));

	DFA_QE->initialStates = (StateTransform*)malloc(sizeof(StateTransform));
	DFA_QE->initialStates->currentState = 0;

	DFA_QE->SucessState = (StateTransform*)malloc(sizeof(StateTransform));
	DFA_QE->SucessState->currentState = 99;
	DFA_QE->SucessState->stateTrue = DFA_QE->SucessState;
	DFA_QE->SucessState->stateFalse = DFA_QE->SucessState;

	DFA_QE->StateArr[0].currentState = 1;
	DFA_QE->StateArr[0].currentBehavior.stringsuccess = 'H';
	DFA_QE->StateArr[0].stateTrue = &(DFA_QE->StateArr[1]);
	DFA_QE->StateArr[0].stateFalse = &(DFA_QE->StateArr[0]);

	DFA_QE->StateArr[1].currentState = 2;
	DFA_QE->StateArr[1].currentBehavior.stringsuccess = 'e';
	DFA_QE->StateArr[1].stateTrue = &(DFA_QE->StateArr[2]);
	DFA_QE->StateArr[1].stateFalse = &(DFA_QE->StateArr[0]);

	DFA_QE->StateArr[2].currentState = 3;
	DFA_QE->StateArr[2].currentBehavior.stringsuccess = 'l';
	DFA_QE->StateArr[2].stateTrue = &(DFA_QE->StateArr[3]);
	DFA_QE->StateArr[2].stateFalse = &(DFA_QE->StateArr[0]);

	DFA_QE->StateArr[3].currentState = 4;
	DFA_QE->StateArr[3].currentBehavior.stringsuccess = 'l';
	DFA_QE->StateArr[3].stateTrue = &(DFA_QE->StateArr[4]);
	DFA_QE->StateArr[3].stateFalse = &(DFA_QE->StateArr[0]);

	DFA_QE->StateArr[4].currentState = 5;
	DFA_QE->StateArr[4].currentBehavior.stringsuccess = 'o';
	DFA_QE->StateArr[4].stateTrue = DFA_QE->SucessState;
	DFA_QE->StateArr[4].stateFalse = &(DFA_QE->StateArr[0]);

	return DFA_QE;
}

int Run_Func_A(DFA* CurrentAutomaton, char inputString[]) {
	int result = 0;
	CurrentAutomaton->initialStates = &CurrentAutomaton->StateArr[0];
	int loopsize = strlen(inputString);
	if (strlen(inputString) == 0) {
		loopsize = 1;
	}
	for (int i = 0; i < loopsize-1; i++) {
		//printf("currentState is: %d \n", CurrentAutomaton->initialStates->currentState);
		//printf("I'm Comparing %c with %c \n", inputString[i], CurrentAutomaton->initialStates->currentBehavior.stringsuccess);
		if (CurrentAutomaton->initialStates->currentState == -1) {
			//printf("Fail State Reached, Terminating function\n");
			break;
		}
		else {
			if (inputString[i] == CurrentAutomaton->initialStates->currentBehavior.stringsuccess) {
				//printf("This is true \n\n");
				CurrentAutomaton->initialStates = CurrentAutomaton->initialStates->stateTrue;
			}
			else {
				//printf("This is false\n\n");
				CurrentAutomaton->initialStates = CurrentAutomaton->initialStates->stateFalse;
			}
		}
	}
	result = CurrentAutomaton->initialStates->currentState;
	//free(CurrentAutomaton->initialStates);
	return result;
}
